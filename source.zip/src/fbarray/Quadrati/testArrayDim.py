from ctypes import *
from fbTypes import *
fba=fbDim(c_long,(-189,-185),(-200,-197))
array=fba.getDesc

print(fba.fb_ArrayCalcElement(array))
print(array.dimensions)
