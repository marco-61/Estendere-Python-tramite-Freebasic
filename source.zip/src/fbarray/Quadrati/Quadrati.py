from fblib.fbTypes import *
PATHLIB=r'.\quadrati.dll'
data=(2,3,4,5, 6,7,8,9, 10,11,12,13, 14,15,16,17)
ar=fbDim(LONG,(1,4),(1,4),data=data)
desc=ar.getDesc
lib=CDLL(PATHLIB)
lib.Quadrati.argtypes=[POINTER(FBArray)]
lib.Quadrati(desc)

for i in range(ar.Lbound(1),ar.Ubound(1)+1):
    for j in range(ar.Lbound(2),ar.Ubound(2)+1):
        print(ar[(i,j)],end='\t')

input('\nPremi Enter per uscire')        
