from ctypes import *
class FBArrayDim(Structure):
    _fields_ = [("elements", c_size_t),
                ("lbound", c_ssize_t),
                ("ubound", c_ssize_t)]



class FBArray2(Structure):
    _fields_ = [("data", c_void_p),
                ("ptr", c_void_p),
                ("size", c_size_t),
                ("element_len", c_size_t),
                 ("dimensions", c_size_t),
                ("flags",  c_ssize_t),     
                ('arraydim',(FBArrayDim*2))]



def CadrI(array,startIndex,Ctype):
    ind=-startIndex   # indice inferiore desiderato
    by=byref(a,ind*sizeof(Ctype)) # calcola l’idirizzo corretto
    p=cast(by, c_void_p);l=len(array)-1  # convertisce in c_void_p       
    return (p, startIndex,startIndex+l)     # ritorna il puntatore e gli indici    

def Moffset(cLbound,rLbound):
    return cLbound+rLbound*sizeof(c_long)

a=(c_long*20)(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20)
r=Moffset(-26,-147)
print(r)
r1=CadrI(a,r,c_long)
p1=pointer(a)


array=FBArray2()
array.data=r1[0]
array.ptr=cast(p1,c_void_p)
array.size=20*sizeof(c_long)
array.element_len=sizeof(c_long)
array.dimensions=2  
array.arraydim[0].elements=5
array.arraydim[0].lbound=-147
array.arraydim[0].ubound=-143
array.arraydim[1].elements=4
array.arraydim[1].lbound=-26
array.arraydim[1].ubound=-23
lib=CDLL(r'.\IntArrayView2.dll')
IntArrayView=lib.IntArrayView
IntArrayView.argtypes=[POINTER(FBArray2)]

IntArrayView(array)
# questo programma va lanciato da console
input('premi enter per uscire')
