
from ctypes import *
class FBArray(Structure):
    _fields_ = [("data", c_void_p),
                ("ptr", c_void_p),
                ("size", c_size_t),
                ("element_len", c_size_t),
                ("dimensions", c_size_t),
                ("flags",  c_ssize_t),                
                ("elements", c_size_t),
                ("lbound", c_ssize_t),
                ("ubound", c_ssize_t)]
a=(c_long*10)(1,2,3,4,5,6,7,8,9,10)
p=pointer(a)

array=FBArray()
array.data=cast(p,c_void_p)
array.ptr=None#cast(p,c_void_p)
array.size=sizeof(p)
array.element_len=sizeof(c_long)
array.dimensions=1
array.elements=len(a)
array.flags=0x00000010
array.lbound=0
array.ubound=9
lib=CDLL('.\IntArraySum.dll')
IntArraySum=lib.IntArraySum
IntArraySum.argtypes=[POINTER(FBArray)]
IntArraySum.restype=c_size_t
r=IntArraySum(array)
print(f"la somma del contenuto dell'array={r}")

input('premi enter')
