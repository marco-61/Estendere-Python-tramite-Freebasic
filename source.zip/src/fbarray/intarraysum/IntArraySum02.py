
from ctypes import *

class FBArray(Structure):
    _fields_ = [("data", c_void_p),
                ("ptr", c_void_p),
                ("size", c_size_t),
                ("element_len", c_size_t),
                ("dimensions", c_size_t),
                ("flags",  c_ssize_t),                     
                ("elements", c_size_t),
                ("lbound", c_ssize_t),
                ("ubound", c_ssize_t)]

def CadrI(array,startIndex,Ctype):
    ind=-startIndex
    by=byref(a,ind*sizeof(Ctype))
    p=cast(by, c_void_p);l=len(array)-1         
    return (p, startIndex,startIndex+l)         


    

a=(c_long*10)(1,2,3,4,5,6,7,8,9,10)
r=CadrI(a, -20,c_long)

array=FBArray()
array.data=r[0] 
array.ptr=None
array.size=sizeof(r[0])
array.element_len=sizeof(c_long)
array.dimensions=1
array.elements=len(a)
array.lbound=r[1]
array.ubound=r[2]

lib=CDLL(r'.\intArraysum.dll')
IntArraySum=lib.IntArraySum
IntArraySum.argtypes=[POINTER(FBArray)]
IntArraySum.restype=c_long
r=IntArraySum(array)
print(f"La somma del contenuto dell'array={r}")

input('premi enter per uscire')

