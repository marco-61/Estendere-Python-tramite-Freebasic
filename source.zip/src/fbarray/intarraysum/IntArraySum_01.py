from fbTypes import *
fba=fbDim(LONG,(30,39),data=(1,2,3,4,5,6,7,8,9,10))
array=fba.getDesc
lib=CDLL('.\IntArraySum.dll')
IntArraySum=lib.IntArraySum
IntArraySum.argtypes=[POINTER(FBArray)]
IntArraySum.restype=c_size_t
r=IntArraySum(array)
print(f"la somma del contenuto dell'array={r}")
input('premi enter per uscire')

