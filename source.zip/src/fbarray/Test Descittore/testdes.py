
from ctypes import *
#from fbTypes import *
class FBArray(Structure):
    _fields_ = [("data", c_void_p),
                ("ptr", c_void_p),
                ("size", c_size_t),
                ("element_len", c_size_t),
                ("dimensions", c_size_t),
                ("flags",  c_ssize_t),                
                ("elements", c_size_t),
                ("lbound", c_ssize_t),
                ("ubound", c_ssize_t)]
a=(c_short*10)(1,2,3,4,5,6,7,8,9,10)
p=pointer(a)

array=FBArray()
array.data=cast(p,c_void_p)
array.ptr=None#cast(p,c_void_p)
array.size=sizeof(p)
array.element_len=sizeof(c_short)
array.dimensions=1
array.elements=len(a)
array.flags=0x00000010 or 0x00000020 or 0x0000000f
array.lbound=0
array.ubound=9
lib=CDLL(r'.\testdes.dll')
test=lib.test
test.argtypes=[POINTER(FBArray)]

test(array)


input('premi enter')
