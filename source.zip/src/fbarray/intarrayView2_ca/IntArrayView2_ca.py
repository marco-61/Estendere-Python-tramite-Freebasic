from fbTypes import *
CTYPE=c_longlong

a=(CTYPE*20)(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20)

d=fb_ArrayCalcDiff((-64,-60),(-46,-43))*sizeof(CTYPE)
r=byref(a,d)
FBARRAY_FLAGS_FIXED_DIM  = 0x00000010 
array=FBArray()
array.data=cast(r,c_void_p)
array.ptr=None
array.size=20*sizeof(CTYPE)
array.element_len=sizeof(CTYPE)
array.dimensions=2  
array.arraydim[0].elements=5
array.arraydim[0].lbound=-64
array.arraydim[0].ubound=-60
array.arraydim[1].elements=4
array.arraydim[1].lbound=-46
array.arraydim[1].ubound=-43
array.flags=FBARRAY_FLAGS_FIXED_DIM
lib=CDLL(r'.\IntArrayView2_ca.dll')
IntArrayView=lib.IntArrayView
IntArrayView.argtypes=[POINTER(FBArray)]

IntArrayView(array)
# questo programma va lanciato da console
input('premi enter per uscire')
