from ctypes import *
from fbTypes import *
fba=fbDim(c_longlong,(1600,1604),(-203,-200),data=None)#(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20))
fba((1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20))
array=fba.getDesc
lib=CDLL(r'.\IntArrayView2_ca.dll')
IntArrayView=lib.IntArrayView
IntArrayView.argtypes=[POINTER(FBArray)]

IntArrayView(array)
# questo programma va lanciato da console

#(-64,-60),(-46,-43)
