from ctypes import *
FBARRAY_FLAGS_DIMENSIONS = 0x0000000f    # number of entries allocated in dimTb()
FBARRAY_FLAGS_FIXED_DIM  = 0x00000010    # array has fixed number of dimensions
FBARRAY_FLAGS_FIXED_LEN  = 0x00000020    # array points to fixed-length memory
FBARRAY_FLAGS_RESERVED   = 0xffffffc0    # reserved, do not use

class FBArrayDim(Structure):
    _fields_ = [("elements", c_size_t),
                ("lbound", c_ssize_t),
                ("ubound", c_ssize_t)]



class FBArray2(Structure):
    _fields_ = [("data", c_void_p),
                ("ptr", c_void_p),
                ("size", c_size_t),
                ("element_len", c_size_t),
                ("dimensions", c_size_t),
                ("flags",  c_ssize_t),     
                ('arradim',(FBArrayDim*2))]

CTYPE=c_short


def CadrI(array,startIndex,Ctype):
    ind=-startIndex   # indice inferiore desiderato
    by=byref(a,ind*sizeof(Ctype)) # calcola l’idirizzo corretto
    p=cast(by, c_void_p);l=len(array)-1  # convertisce in c_void_p       
    return (p, startIndex,startIndex+l)     # ritorna il puntatore e gli indici    

    

a=(CTYPE*20)(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20)
r1=CadrI(a, -10,CTYPE) # la seconda dimensione negativa

array=FBArray2()
array.data=r1[0]
array.ptr=None
array.size=20*sizeof(CTYPE)#sizeof(r1[0])
array.element_len=sizeof(CTYPE)
print("\n---------matrice 5x4---------")
array.dimensions=2
array.flags=FBARRAY_FLAGS_FIXED_DIM
array.arradim[0].elements=5
array.arradim[0].lbound=0
array.arradim[0].ubound=4
array.arradim[1].elements=4
array.arradim[1].lbound=-10
array.arradim[1].ubound=-7
lib=CDLL(r'.\intarrayView2_c.dll')
IntArrayView=lib.IntArrayView
IntArrayView.argtypes=[POINTER(FBArray2)]
IntArrayView(array)

print("\n---------matrice 4x5---------")
array.arradim[0].elements=4
array.arradim[0].lbound=0
array.arradim[0].ubound=3
array.arradim[1].elements=5
array.arradim[1].lbound=-10
array.arradim[1].ubound=-6
IntArrayView(array)

print("\n---------matrice 2x10---------")

array.arradim[0].elements=2
array.arradim[0].lbound=0
array.arradim[0].ubound=1
array.arradim[1].elements=10
array.arradim[1].lbound=-10
array.arradim[1].ubound=-1
IntArrayView(array)

print("\n---------matrice 10x2----------")
array.arradim[0].elements=10
array.arradim[0].lbound=0
array.arradim[0].ubound=9
array.arradim[1].elements=2
array.arradim[1].lbound=-10
array.arradim[1].ubound=-9
IntArrayView(array)

