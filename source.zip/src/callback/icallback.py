from ctypes import * # ricevente python
import os
LIBPATH=r'.\callback.dll'
lib=CDLL(LIBPATH)
test=lib.test   # callback Python
@CFUNCTYPE(c_long,c_long,c_long) # definisce il prototype del funzione py_sum il primo parametro è quello di ritorno (return, a, b)
def py_sum(a,b):
    return a+b
a,b=5,6
r=test(a,b,py_sum) # chiamo la funzione Freebasic che richiama Python
print('Python dice: %d+%d=%r'%(a,b,r))
input('premi enter per uscire')

