from ctypes import *
class myStruct(Structure):
    _fields_=[('x',c_long),
              ('y',c_long),
              ('risultato',c_long)]
LIBPATH='.\\structSum2.dll'    
lib=CDLL(LIBPATH)
a=myStruct(13,76,0)
lib.structSum.argtypes=[POINTER(myStruct)]
lib.structSum(a)
print(f'{a.x} + {a.y} = {a.risultato}')
input('Premi enter per uscire')
