# converte e ripristina l'estensione di una dll
# da dll a dl_ e viceversa per poterla inviare via email
import os

mydll=[".\\src\callback\\callback",".\\src\\Classi in Freebasic\\MySum_metodo_1\\mysum",
       ".\\src\\Classi in Freebasic\\MySum_metodo_2\\mysum2",".\\src\\fbarray\\intarraysum\\intarraysum",
       ".\\src\\fbarray\\intarrayView2\\intarrayView2",".\\src\\fbarray\\intarrayView2_c\\intarrayView2_c",
       ".\\src\\fbarray\\intarrayView2_ca\\intarrayView2_ca",".\\src\\fbarray\\intarrayView2_cb\\intarrayView2_cb",
       ".\\src\\fbarray\\intarrayView3\\intarrayView3",".\\src\\fbarray\\Quadrati\\Quadrati",
       ".\\src\\fbarray\\Test Descittore\\testdes",".\\src\\fblib\\fbConsole\\dll\\fbConsole",
       ".\\src\\fblib\\PyObj\\Esempi\\esempio tuple\\esempio tuple",".\\src\\fblib\\PyObj\\Esempi\\pydict_esempio_1\\pydict_esempio_1",
       ".\\src\\fblib\\PyObj\\Esempi\\pydict_esempio_2\\pydict_esempio_2",".\\src\\fblib\\PyObj\\Esempi\\pyobj_esempio_1\\pyobj_esempio_1",
       ".\\src\\fblib\\PyObj\\Esempi\\pyobj_esempio_2\\pyobj_esempio_2",".\\src\\fblib\\PyObj\\Esempi\\pySet_esempio\\esempio_set_1",
       ".\\src\\fblib\\PyObj\\Esempi\\view_list\\view_list",".\\src\\myadd\\myadd",
       ".\\src\\structSum\\structSum",".\\src\\structSum2\\structSum2"]


for f in mydll:
    filename=f+".dll"
    filename2=f+".dl_"
    if os.access(filename,os.F_OK):
        os.rename(filename,filename2)
    else:
        os.rename(filename2,filename)

input("Conversione avvenuta con successo.\n\nPremi Enter per terminare")        
