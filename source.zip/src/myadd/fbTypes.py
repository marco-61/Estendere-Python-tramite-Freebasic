from ctypes import *
_FB64_=True  # impostare a True se il compilatore freebasic è a 64 bit altrimenti a False se a 32 bit
class FBSTRING(Structure):
    _fields_=[('pointer',c_char_p),
              ('len',c_ssize_t),
              ('size',c_ssize_t)]

FB_MAXDIMENSIONS=8  # Massimo numero di dimensioni
FBARRAY_FLAGS_DIMENSIONS = 0x0000000f    # number of entries allocated in dimTB()
FBARRAY_FLAGS_FIXED_DIM  = 0x00000010    # array has fixed number of dimensions
FBARRAY_FLAGS_FIXED_LEN  = 0x00000020    # array points to fixed-length memory
FBARRAY_FLAGS_RESERVED   = 0xffffffc0    # reserved, do not use
# tipi interi    
BYTE=c_byte
UBYTE=c_ubyte
SHORT=c_short
USHORT=c_ushort
if _FB64_:
    INTEGER=c_longlong
    UINTEGER=c_ulonglong
else:
    INTEGER=c_int
    UINTEGER=c_uint    
LONG=c_long
ULONG=c_ulong
LONGINT=c_longlong
ULONGINT=c_ulonglong
# virgola mobile
SINGLE=c_float
DOUBLE=c_double
#ptr
ZSTRING=c_char_p
WSTRING=c_wchar_p
STRING=POINTER(FBSTRING)
ANY=c_void_p
PTR=POINTER

class Video(Structure):
    _fields_=[('attr',c_int),
              ('char',c_int)]
class Area(Structure):
    _fields_=[('id',c_ubyte),
              ('height',c_int),
              ('width',c_int),
              ('buff',POINTER(Video))]

    
class FBArrayDim(Structure):
    _fields_ = [("elements", c_size_t),
                ("lbound", c_ssize_t),
                ("ubound", c_ssize_t)]
    
class FBArray(Structure):
    _fields_ = [("data", c_void_p),
                ("ptr", c_void_p),
                ("size", c_size_t),
                ("element_len", c_size_t),
                ("dimensions", c_size_t),
                ("flags",  c_ssize_t),     
                ('arraydim',(FBArrayDim*FB_MAXDIMENSIONS))]    

def CadrI(array,startIndex,Ctype):
    ind=-startIndex   # indice inferiore desiderato
    by=byref(array,ind*sizeof(Ctype)) # calcola l’idirizzo corretto
    p=cast(by, c_void_p);l=len(array)-1  # convertisce in c_void_p       
    return (p, startIndex,startIndex+l)     # ritorna il puntatore e gli indici    

def fb_ArrayCalcDiff(dimensions,*args):
    diff=0
    if dimensions<=0: return 0
    for i in range(dimensions-1):
        elements=(args[i+1][1]-args[i+1][0])+1
        diff=(diff+args[i][0])*elements
    diff +=args[dimensions-1][0]
    return -diff

class fbDim:
    def __init__(self,Ctype,*args,data=None):
        assert len(args)>=1 or len(args) <= FB_MAXDIMENSIONS,"Numero di dimensioni errato"
        self._Ctype =Ctype
        self._data=data
        self._fbarray=FBArray()
        self._ctarray=None
        self._fbarray.dimensions=len(args)
        self._fbarray.element_len=sizeof(self._Ctype)
        for i,j in enumerate(args):
            l,u=j
            self._fbarray.arraydim[i].elements=abs(u-l)+1
            self._fbarray.arraydim[i].lbound=l
            self._fbarray.arraydim[i].ubound=u
        self._elements=fb_ArrayCalcElement(self._fbarray)        
        self._fbarray.flags=FBARRAY_FLAGS_FIXED_DIM
        if self._data is None: self._data=(0,)*self._elements
        self._ctarray=(self._Ctype*self._elements)(*self._data) #alloca l'area
        d=self.fb_ArrayCalcDiff(self._fbarray.dimensions,*args)*sizeof(self._Ctype)
        r=byref(self._ctarray,d)        
        self._fbarray.data=cast(r,c_void_p)
        self._fbarray.ptr=None # utilizzato da freebasic per una allocazione in runtime
        self._fbarray.size=self._elements*sizeof(Ctype)
    @property
    def getDesc(self):
         return self._fbarray       
    def fb_ArrayCalcElement(self,ardes):
        elements=1
        for i in range(ardes.dimensions):
            elements*=abs((ardes.arraydim[i].ubound)-(ardes.arraydim[i].lbound))+1
        return elements
    def __call__(self,*args):
        if len(self._ctarray)<=len(args):
            for i,j in enumerate(args):
                self._ctarray[i]=j   
    def fb_ArrayCalcDiff(self,dimensions,*args):
        diff=0
        if dimensions<=0: return 0
        for i in range(dimensions-1):
            elements=(args[i+1][1]-args[i+1][0])+1
            diff=(diff+args[i][0])*elements
        diff +=args[dimensions-1][0]
        return -diff
