from fbTypes import *
import os
LIBPATH='.\\myadd.dll'
lib=CDLL(LIBPATH) #carica la libreria
def myadd(tipo,a,b):
    global lib
    tipo=tipo.upper() # Trasforma la stringa in maiuscolo    
    tipo2=tipo.encode() # stringa di bytes no unicode  
    s=FBSTRING(tipo2,len(tipo),1)
    if tipo=='INTEGER':
        a1=c_int(a)
        b1=c_int(b)
        lib.myadd.argtypes=[POINTER(FBSTRING),POINTER(c_int) ,POINTER(c_int) ]
        lib.myadd.restype=POINTER(c_int)             
        r=lib.myadd(s,a1,b1)
        return r[0]  #.contents.value
    elif tipo=='SINGLE': 
        a2=c_float(a)
        b2=c_float(b)
        lib.myadd.argtypes=[POINTER(FBSTRING),POINTER(c_float) ,POINTER(c_float) ]
        lib.myadd.restype=POINTER(c_float)                     
        r=lib.myadd(s,a2,b2)
        return r[0]   #.contents.value
    else:
        raise TypeError('Solo INTEGER o SINGLE')
    
print('Somma di 2 interi a+b={}'.format(myadd('Integer',5,7)))
print('Somma di 2 float a+b={}'.format(myadd('Single',5.7,7.8)))    
