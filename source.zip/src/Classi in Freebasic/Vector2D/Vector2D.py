from math import sqrt

class Vector2D:

    def __init__(self,x,y): # costruttore
       self.x,self.y=x,y 

    def __str__(self): # Operator Vector2D.cast () As String
        return f'({self.x},{self.y})'

    @property
    def length(self): 
        return sqrt(self.x*self.x+self.y*self.y)

    @length.setter
    def length(self,new_lenght ):
       m=self.length
       if m !=0:
           self.x*=new_lenght / m   
           self.y*=new_lenght / m 

  
a = Vector2D(3.0,4.0)
print(f"a =  {a}")
print(f"a.length =  {a.length} \n") 


a.length = 10

print(f"a =  {a}")
print(f"a.length =  {a.length}") 
