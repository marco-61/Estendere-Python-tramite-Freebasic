from ctypes import *   
import os
LIBPATH=r'.\mysum2.dll'
#carica la libreria
lib=CDLL(LIBPATH)
#inizializza la classe
lib.somma.restype=c_int
lib.change.argtypes=[c_int,c_int]
lib.init.argtypes=[c_int,c_int]
lib.init(c_int(3),c_int(5))
#lib.init(3,5)
print('Somma i valori di default 3+5={}'.format(lib.somma()))
lib.change(c_int(45),c_int(34))
# effettua la somma
print('La somma di 45+34={}'.format(lib.somma()))

lib.change(c_int(88),c_int(63))# cambia i valori
print('La somma di 88+63={}'.format(lib.somma()))
