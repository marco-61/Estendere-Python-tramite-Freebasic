from ctypes import *
import os
LIBPATH=r'.\mysum.dll'
lib=CDLL(LIBPATH) #carica la libreria
lib.somma.restype=c_int
lib.change.argtypes=[c_int,c_int]
print('somma i valori di default di a+b={}'.format(lib.somma()))
lib.change(c_int(45),c_int(34))
#effettua la somma
print('la somma di 45+34={}'.format(lib.somma()))
lib.change(c_int(88),c_int(63))# cambia i valori
print('la somma di 88+63={}'.format(lib.somma()))
