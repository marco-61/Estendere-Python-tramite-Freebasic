from fblib.PyObj.pyDict import *
from fblib.PyObj.PyStruct import *
LIBPATH=r'.\pydict_esempio_2.dll'
#'Tuple':(5,6.5,'Hei')
d={'Cane':'Doberman','Eta':10,'Byte':55,'Float':4.5,'Tuple':(5,6.5,'Hei')}
pyd=PyDictExport(d)
lib=CDLL(LIBPATH)
pyo=pyd.getObj # ricevi il descrittore della lista
lib.test.argtypes=[POINTER(py2fbDict)]
lib.test(pyo)
print('\n')
input('Premi enter per uscire')
