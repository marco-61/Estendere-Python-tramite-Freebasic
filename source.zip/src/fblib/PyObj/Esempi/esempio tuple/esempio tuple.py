from fblib.PyObj.pyTuple import *
from fblib.PyObj.PyStruct import *

LIBPATH=r'.\esempio tuple.dll'
#l1=[1,3,(5,6.5,'Hei'),[45,67,'Sole nero'],7+7j]
#t1=(77,99,(55,'cane'),8+3j,[77,'By By'])
t1=(-14,254,1234,32770,2147483645,4294967295,9223372036854775805,18446744073709551614,\
    b'Hei La','Ciao',3.5,1.797693134862316e+307,7+7j,(5,6.5,'Hei'),\
    [45,67,'Sole nero'],{1,2,4,5},{'a':1,'b':2})
pte=PyTupleExport(t1)
lib=CDLL(LIBPATH)

pyt=pte.getObj # ricevi il descrittore della tupla

lib.init.argtypes=[POINTER(py2fbTuple)]
lib.init(pyt)
lib.test()
input("Premi enter per uscire")



