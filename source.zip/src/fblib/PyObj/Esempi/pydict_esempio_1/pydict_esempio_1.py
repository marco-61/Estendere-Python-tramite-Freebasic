from fblib.PyObj.pyDict import *
from fblib.PyObj.PyStruct import *
LIBPATH=r'.\pydict_esempio_1.dll'
d={'Cane':'Doberman','Eta':10,'Lista':[45,67,'Sole nero'],'Tuple':(5,6.5,'Hei')}
pyd=PyDictExport(d)
lib=CDLL(LIBPATH)
pyo=pyd.getObj # ricevi il descrittore della lista
lib.init.argtypes=[POINTER(py2fbDict)]
lib.init(pyo)
lib.test()
print("\n\n--------------------Controllo l'inserimento da Python-----------------")
print(d)
input('Premi enter per uscire')
