from fblib.PyObj.pyTuple import *
from fblib.PyObj.pySet import *
from fblib.PyObj.PyStruct import *

LIBPATH=r'.\esempio_set_1.dll'
s1={1,2,4}
pte=PySetExport(s1)
lib=CDLL(LIBPATH)

pyt=pte.getObj # ricevi il descrittore

lib.init.argtypes=[POINTER(py2fbSet)]
lib.init(pyt)
lib.test()
print("\n\nControllo l'inserimento da Python")
print(s1)

input("Premi enter per uscire")
