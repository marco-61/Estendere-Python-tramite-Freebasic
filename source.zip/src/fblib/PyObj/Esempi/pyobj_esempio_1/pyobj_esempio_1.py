from fblib.PyObj.pyTuple import *
from fblib.PyObj.pyList import *
from fblib.PyObj.PyStruct import *
LIBPATH=r'.\pyobj_esempio_1.dll'
l1=[1,3,(5,6.5,'Hei'),[45,67,'Sole nero'],(7+7j)]
t1=(77,99,(55,'cane'),(8+3j),[77,'By By'])
ple=PyListExport(l1)
pte=PyTupleExport(t1)
lib=CDLL(LIBPATH)
pyl=ple.getObj # ricevi il descrittore della lista
pyt=pte.getObj # ricevi il descrittore della tupla

lib.init.argtypes=[POINTER(py2fbList),POINTER(py2fbTuple)]
lib.init(pyl,pyt)
lib.test()
print("\n\nControllo l'inserimento da Python\n")
print(l1)

print("\n\nliste create da Freebasic\n")
for i in ple.values():
    print(i.value)
    print(f"id={i.getObj.id}")
    
print("\n\ntuple create da Freebasic\n")
for i in pte.values():
    print(i.value)
    print(f"id={i.getObj.id}")

input("Premi enter per uscire")
