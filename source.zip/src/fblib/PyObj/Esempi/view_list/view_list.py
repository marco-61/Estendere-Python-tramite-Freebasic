from fblib.PyObj.pyList import *
from fblib.PyObj.PyStruct import *
LIBPATH='.\\view_list.dll'
lib=CDLL(LIBPATH)

l1=[-14,254,1234,65535,32770,2147483645,9223372036854775805,1.797693134862316e+307,7+7j,(5,6.5,'Hei'),[45,67,'Sole nero'],{1,2,4,5},{'a':1,'b':2}]
ple=PyListExport(l1)
pls=ple.getObj # ricevi il descrittore della tupla

lib.init.argtypes=[POINTER(py2fbList)]
lib.init(pls)
lib.test()
input('Premi un enter per uscire')
