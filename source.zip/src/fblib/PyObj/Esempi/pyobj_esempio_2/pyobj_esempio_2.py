from fblib.PyObj.pyList import *
from fblib.PyObj.PyStruct import *

LIBPATH=r'.\pyobj_esempio_2.dll'
l1=[1,3,(5,6.5,'Hei'),[45,67,'Sole nero'],7+7j]


ple=PyListExport(l1)
lib=CDLL(LIBPATH)

pyt=ple.getObj # ricevi il descrittore della tupla

lib.init.argtypes=[POINTER(py2fbList)]
lib.init(pyt)
lib.test()
input('Premi enter per uscire')

