# metodi comuni 
from fblib.PyObj import *
from ctypes import *
from fblib.PyObj.PyStruct import *

class let: 
    def __init__(self,obj,py2fbStruct):
        """ Wrapper assegnamento nuovo valore """
        self.obj=obj
        self.py2fbStruct=py2fbStruct
        let=CFUNCTYPE(None,c_wchar_p)
        self.py2fbStruct.let=cast(let(self._let_),POINTER(c_uint))
    def _let_(self,t):
        t2=eval(t) # valuta la stringa
        self.obj=t2 #assegna il nuovo valore
    @property
    def value(self): # ritorna il valore
        return self.obj

        
class is_type:
    def __init__(self,obj,py2fbStruct,indexInt):
        """ Wrapper Controllo del tipo in un contenitore"""
        self.let=obj
        self.maxFloat=3.4*10**38
        self.minFloat=-3.4*10**(-38)
        self.obj=self.let.value
        self.py2fbStruct=py2fbStruct
        self.indexInt=indexInt
        if indexInt:
            isType=CFUNCTYPE(c_int,c_int)
        else:
            isType=CFUNCTYPE(c_int,c_wchar_p)
        self.py2fbStruct.isType=cast(isType(self._is_type_),POINTER(c_uint))        
    def _is_type_(self,index):
        self.obj=self.let.value
        if isinstance(self.obj[index],bool):
            return 0       
        elif isinstance(self.obj[index],int):
            return self._intBit_(self.obj[index]) #controlla che tipo di intero
        elif isinstance(self.obj[index],float):
            if self.obj[index]> self.maxFloat or self.obj[index]<self.minFloat :
                return 10
            return 2
        elif isinstance(self.obj[index],bytes):
            return 3
        elif isinstance(self.obj[index],str):
            return 4        
        elif isinstance(self.obj[index],list):
            return 5
        elif isinstance(self.obj[index],tuple):
            return 6
        elif isinstance(self.obj[index],dict):
            return 7
        elif isinstance(self.obj[index],set):
            return 8
        elif isinstance(self.obj[index],complex):
            return 9        
        else:
            return -1 # non riconosciuto
        
    def  _intBit_(self,t): # controllo per i vari interi
        if   t.bit_length()<=7: return 14 #byte
        elif t.bit_length()==8: return 15 #ubyte
        elif t.bit_length() in range(9,16): return 12 # short
        elif t.bit_length()==16: return 13 # Ushort         
        elif t.bit_length() in range(17,32) : return 1 #pyInt  PyLong
        elif t.bit_length()==32 : return 11 #Pyuint PyuLong      
        elif t.bit_length() in range(33,64)  : return 16 #Pylongint               
        elif t.bit_length()==64 : return 17 #Pyulongint                
        
class getitem:
    def __init__(self,obj,py2fbStruct,Buffer,tipoInt):
        """ Wrapper al magic method __getitem__"""
        self.let=obj
        self.obj=self.let.value
        self.py2fbStruct=py2fbStruct  
        self.buffer=Buffer # wstring buffer e zstring buffer
        if tipoInt:
            ass=CFUNCTYPE(None,c_int,c_int,c_void_p)
        else:
            ass=CFUNCTYPE(None,c_int,c_wchar_p,c_void_p)
        self.py2fbStruct.getitem=cast(ass(self._getitem_),POINTER(c_uint))        
    def _getitem_(self,tipo,index,ptr):
        self.obj=self.let.value
        v=self.obj[index]
        p=ptr_convert(tipo,ptr)
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            p[0]=v
        elif tipo==3:
            self.buffer.strbuff=v.decode() # wstring ritorna in wbuff
            self.buffer.bytbuff=v # wstring ritorna in wbuff
        elif tipo==4: # wstring
            #v=self.obj[index]
            self.buffer.strbuff=v # wstring ritorna in wbuff
            self.buffer.bytbuff=v.encode() # wstring ritorna in wbuff
        elif tipo in (5,6,7,8,9): # list,tuple,dict,set,complex in formato string
            v=repr(v)#repr(self.obj[index])
            self.buffer.strbuff=v # wstring ritorna in wbuff
            self.buffer.bytbuff=v.encode() # wstring ritorna in wbuff
            
class setitem:
    def __init__(self,obj,py2fbStruct,tipoInt):
        """ Wrapper al magic method __setitem__"""
        self.let=obj
        self.obj=self.let.value
        self.pystrb=pyStrBuffer() # wstring buffer
        self.pybytb=pyBytesBuffer() # zstring buffer
        self.py2fbStruct=py2fbStruct
        self.tipoInt=tipoInt
        if tipoInt:
            ass=CFUNCTYPE(None,c_int,c_int,c_void_p)
        else:
            ass=CFUNCTYPE(None,c_int,c_wchar_p,c_void_p)
        self.py2fbStruct.setitem=cast(ass(self._setitem_),POINTER(c_uint))
        
    def _setitem_(self,tipo,index,ptr):
        self.obj=self.let.value
        p=ptr_convert(tipo,ptr)
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            self.obj[index]=p[0]
        elif tipo in (3,4):
            self.obj[index]=p.value
        elif tipo in (5,6,7,8,9):    
            self.obj[index]=eval(p.value)    


class  copy_clear: # usato da list,dict, set e simili
    def __init__(self,obj,py2fbStruct,myClass,ClassPtr,mem):
        """ Wrapper ai metodi copy e clear """
        self.let=obj
        self.obj=self.let.value
        self.py2fbStruct=py2fbStruct
        self.myClass=myClass
        self.ClassPtr=ClassPtr
        self.mem=mem
        #--------------------------Copy--------------------------------------   
        ass=CFUNCTYPE(None,POINTER(self.ClassPtr))
        self.py2fbStruct.copy=cast(ass(self._copy_),POINTER(c_uint))
        #--------------------------Clear--------------------------------------   
        clear=CFUNCTYPE(None)
        self.py2fbStruct.clear=cast(clear(self.obj.clear),POINTER(c_uint))   
        
    def _copy_(self,buffer):
        self.obj=self.let.value
        d=self.obj.copy();key=len(self.mem)
        self.mem[key]=self.myClass(d) # creo un nuovo oggetto
        memmove(buffer,byref(self.mem[key].getObj),sizeof(self.py2fbStruct))#copio il descrittore
    
class  contains: # in per i valori usato da tuple,list,set e dict
    def __init__(self,obj,py2fbStruct,tipoInt):
        """ Wrapper al magic method __contains__"""
        self.let=obj
        self.obj=self.let.value
        self.py2fbStruct=py2fbStruct
        if tipoInt:
            ass=CFUNCTYPE(c_bool,c_int,c_void_p) #Liste,Tuple e simili
            self.py2fbStruct.In=cast(ass(self._contains_),POINTER(c_uint))             
        else:
            ass=CFUNCTYPE(c_bool,c_wchar_p) #Dizionari         
            self.py2fbStruct.In=cast(ass(self._contains2_),POINTER(c_uint))         
    def _contains_(self,tipo,ptr):       
        self.obj=self.let.value        
        p=ptr_convert(tipo,ptr)        
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            return p[0] in self.obj
        elif tipo in (3,4):
            return p.value in self.obj
        elif tipo in (5,6,7,8,9):
            return (eval(p.value) in self.obj)
    def _contains2_(self,key):
        self.obj=self.let.value  
        return key in self.obj
class Slice:
    def __init__(self,obj,py2fbStruct,myClass,mem):
        """ Wrapper al slice del magic method __getitem__"""
        self.let=obj
        self.obj=self.let.value
        self.py2fbStruct=py2fbStruct
        self.myClass=myClass
        self.mem=mem 
        ass=CFUNCTYPE(None,POINTER(py2fbList),c_int,c_int,c_int)
        self.py2fbStruct.slice=cast(ass(self._slice_),POINTER(c_uint))             
    def _slice_(self,buffer,start,end,step):
        self.obj=self.let.value
        t=self.obj[start:end:step];key=len(self.mem)
        self.mem[key]=self.myClass(t)
        memmove(buffer,byref(self.mem[key].getObj),sizeof(self.py2fbStruct))
                  
class toString:
    def __init__(self,obj,py2fbStruct,buffer):
        """ Wrapper ai magic metod __str__ e __repr__"""
        self.let=obj
        self.obj=self.let.value
        self.py2fbStruct=py2fbStruct
        self.buffer=buffer   
        s=CFUNCTYPE(None)
        self.py2fbStruct.str=cast(s(self._str_),POINTER(c_uint))        
        s=CFUNCTYPE(None)
        self.py2fbStruct.repr=cast(s(self._repr_),POINTER(c_uint))                     
    def _str_(self):
        self.obj=self.let.value
        v=str(self.obj)
        self.buffer.strbuff=v # wstring ritorna in wbuff
        self.buffer.bytbuff=v.encode() # zstring ritorna in zbuff
    def _repr_(self):
        self.obj=self.let.value
        v=repr(self.obj)
        self.buffer.strbuff=v # wstring ritorna in wbuff
        self.buffer.bytbuff=v.encode() #  ritorna in zbuff


class newObj:
    def __init__(self,obj,py2fbStruct,myClass,mytype,ClassPtr,mem):
        """ Wrapper per la creazione di un nuovo oggetto da Freebasic"""
        self.obj=obj
        self.py2fbStruct=py2fbStruct
        self.myClass=myClass
        self.mytype=mytype
        self.mem=mem # per la persistenza dell'oggetto
        ass=CFUNCTYPE(None,ClassPtr,c_wchar_p)
        self.py2fbStruct.newObj=cast(ass(self._newObj_),POINTER(c_uint)) 
    def _newObj_(self,buffer,elenco):
        t=eval(elenco) #valuta ls stringa
        if not isinstance(t,self.mytype):t=mytype()# oggetto vuoto se tipo errato
        key=len(self.mem);self.mem[key]=self.myClass(t)
        memmove(buffer,byref(self.mem[key].getObj),sizeof(self.py2fbStruct)) # copio il descrittore

class delitem:
    def __init__(self,obj,py2fbStruct,tipoInt):
        """ Wrapper al magic method __delitem__"""
        self.let=obj
        self.obj=self.let.value
        self.py2fbStruct=py2fbStruct
        if tipoInt:
            d=CFUNCTYPE(None,c_int)
        else:
            d=CFUNCTYPE(None,c_wchar_p)            
        self.py2fbStruct.delitem=cast(d(self._delitem_),POINTER(c_uint))

    def _delitem_(self,index):
        self.obj=self.let.value
        del(self.obj[index])
        
class Del:
    def __init__(self,mem,py2fbStruct):
        """ Wrapper per la cancellazione dell'oggetto Python libera la memoria
            e permette di riutilizzare una variabile Freebasic assegnata ad un oggetto precedente"""
        self.py2fbStruct=py2fbStruct
        d=CFUNCTYPE(None,c_int)
        self.py2fbStruct.Del=cast(d(self._Del_),POINTER(c_uint))
        self.mem=mem
    def _Del_(self,index):
        if index>=0: del(self.mem[index])
        
class Len:
    def __init__(self,obj,py2fbStruct):
        """ Wrapper al magic metod __len__"""
        self.let=obj
        self.obj=self.let.value
        self.py2fbStruct=py2fbStruct
        d=CFUNCTYPE(c_int)
        self.py2fbStruct.len=cast(d(self._len_),POINTER(c_uint))
        # chiama il metodo originale
    def _len_(self):
         self.obj=self.let.value   
         return len(self.obj)   
class buffer:
    def __init__(self,obj,py2fbStruct):
        """ Wrapper per creare i buffer di memoria str e bytes""" 
        self.let=obj
        self.obj=self.let.value
        self.py2fbStruct=py2fbStruct
        self.pystrb=pyStrBuffer() # wstring buffer
        self.pybytb=pyBytesBuffer() # zstring buffer
        p=self.pybytb.pBuffer
        self.py2fbStruct.zbuff=cast(p,POINTER(c_uint))
        p2=self.pystrb.pBuffer      
        self.py2fbStruct.wbuff=cast(p2,POINTER(c_uint))
        
    @property    
    def strbuff(self):# ritorna il valore del wstring buffer
        return  self.pystrb.buffer
    @strbuff.setter
    def strbuff(self,value): # setta un valore nel wstring buffer
        self.pystrb.buffer=value
    @property        
    def bytbuff(self): # ritorna il valore del zstring buffer
        return  self.pybytb.buffer 
    @bytbuff.setter
    def bytbuff(self,value): # setta un valore nel zstring buffer
        self.pybytb.buffer=value
        
class count_index:
    def __init__(self,obj,py2fbStruct):
        """ Wrapper ai metodi count e index"""
        self.let=obj
        self.obj=self.let.value
        self.py2fbStruct=py2fbStruct
        index=CFUNCTYPE(c_int,c_int,c_void_p,c_int,c_int)
        self.py2fbStruct.index=cast(index(self._index_),POINTER(c_uint))    
        count=CFUNCTYPE(c_int,c_int,c_void_p)
        self.py2fbStruct.count=cast(count(self._count_),POINTER(c_uint))  
    def _index_(self,tipo,ptr,start,stop):
        self.obj=self.let.value
        p=ptr_convert(tipo,ptr)    
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            return self.obj.index(p[0],start,stop)
        elif tipo in (3,4):
            return self.obj.index(p.value,start,stop)
        elif tipo in (5,6,7,8,9):
            return self.obj.index(eval(p.value),start,stop)  
            
    def _count_(self,tipo,ptr):
        self.obj=self.let.value        
        p=ptr_convert(tipo,ptr)
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            p=cast(ptr,POINTER(c_float)) #cast puntatore
            return self.obj.count(p[0])
        elif tipo in (3,4):
            return self.obj.count(p.value)
        elif tipo in (5,6,7,8,9):
            return self.obj.count(eval(p.value))
        
def ptr_convert(tipo, ptr):# funzione che converte il puntatore a secondo il tipo richiesto
    if tipo==0: #Bool
        p=cast(ptr,POINTER(c_bool)) #cast puntatori
    elif tipo==1:#int
        p=cast(ptr,POINTER(c_int))
    elif tipo==2:#float
        p=cast(ptr,POINTER(c_float)) 
    elif tipo==3:#zstring
        p=cast(ptr,c_char_p) 
    elif tipo in (4,5,6,7,8,9):#wstring
        p=cast(ptr,c_wchar_p)
    elif tipo==10:#double
        p=cast(ptr,POINTER(c_double))
    elif tipo==11:#ulong
        p=cast(ptr,POINTER(c_uint))
    elif tipo==12:#Short
        p=cast(ptr,POINTER(c_short)) #cast puntatore
    elif tipo==13:#UShort
        p=cast(ptr,POINTER(c_ushort)) #cast puntatore
    elif tipo==14:#Byte
        p=cast(ptr,POINTER(c_byte)) #cast puntatore
    elif tipo==15:#ubyte
        p=cast(ptr,POINTER(c_ubyte)) #cast puntatore
    elif tipo==16:#longInt
        p=cast(ptr,POINTER(c_longlong)) #cast puntatore
    elif tipo==17:#uLongInt
        p=cast(ptr,POINTER(c_ulonglong)) #cast puntatore        
    return p


        
