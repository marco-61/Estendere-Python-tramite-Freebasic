from fblib.PyObj.pybase import *
from fblib.PyObj.list_method import *
from fblib.PyObj.contains import *
class PyListExport(Contains):
    _mem={}
    def __init__(self,lista=[]):
        super().__init__(lista,list,py2fbList,PyListExport,self._mem)
        #----------------------------------------------------
        self.is_type =is_type(self.let,self.py2fbStruct,True)
        self.getitem=getitem(self.let,self.py2fbStruct,self.buffer,True)
        self.setitem=setitem(self.let,self.py2fbStruct,True)
        self.delitem=delitem(self.let,self.py2fbStruct,True)
        self.count_index=count_index(self.let,self.py2fbStruct)
        self.contains=contains(self.let,self.py2fbStruct,True)
        self.slice=Slice(self.let,self.py2fbStruct,PyListExport,self._mem)
        self.toString=toString(self.let,self.py2fbStruct,self.buffer)
        self.len=Len(self.let,self.py2fbStruct)
        self.list_method=list_method(self.let,self.py2fbStruct,self.buffer,PyListExport)        
        self.copy_clear=copy_clear(self.let,self.py2fbStruct,PyListExport,self.ClassPtr,self._mem)          
        self.newObj=newObj(self.let,self.py2fbStruct,PyListExport,list,self.ClassPtr,self._mem)   
        self.Del=Del(self._mem,self.py2fbStruct)
