from ctypes import *

class py2fbList(Structure):
    _fields_=[('getitem',  POINTER(c_uint)),
              ('setitem',  POINTER(c_uint)),                    
              ('delitem',  POINTER(c_uint)),
              ('append',   POINTER(c_uint)),              
              ('pop',      POINTER(c_uint)),              
              ('index',    POINTER(c_uint)),              
              ('count',    POINTER(c_uint)),              
              ('remove',   POINTER(c_uint)),              
              ('insert',   POINTER(c_uint)),                    
              ('reverse',  POINTER(c_uint)),
              ('clear',    POINTER(c_uint)),
              ('In',       POINTER(c_uint)),                           
              ('isType',   POINTER(c_uint)),
              ('len',      POINTER(c_uint)),
              ('str',      POINTER(c_uint)),
              ('repr',     POINTER(c_uint)),                        
              ('sort',     POINTER(c_uint)),              
              ('slice',    POINTER(c_uint)),
              ('let',      POINTER(c_uint)),
              ('copy',     POINTER(c_uint)),                    
              ('newObj',   POINTER(c_uint)),
              ('zbuff',    POINTER(c_uint)),
              ('wbuff',    POINTER(c_uint)),
              ('Del',      POINTER(c_uint)),
              ('id',       c_int)]
    
class py2fbTuple(Structure):
    _fields_=[('getitem',  POINTER(c_uint)),           
              ('In',       POINTER(c_uint)),                
              ('isType',   POINTER(c_uint)),
              ('len',      POINTER(c_uint)),
              ('index',    POINTER(c_uint)),              
              ('count',    POINTER(c_uint)),              
              ('str',      POINTER(c_uint)),
              ('repr',     POINTER(c_uint)),                
              ('slice',    POINTER(c_uint)),              
              ('let',      POINTER(c_uint)),              
              ('newObj',   POINTER(c_uint)),            
              ('zbuff',    POINTER(c_uint)),
              ('wbuff',    POINTER(c_uint)),
              ('Del',      POINTER(c_uint)),
              ('id',       c_int)]

class py2fbDict(Structure):
    _fields_=[('getitem',   POINTER(c_uint)),    
              ('setitem',   POINTER(c_uint)),                            
              ('delitem',   POINTER(c_uint)),
              ('pop',       POINTER(c_uint)),              
              ('clear',     POINTER(c_uint)),
              ('In',        POINTER(c_uint)),                        
              ('isType',    POINTER(c_uint)),
              ('len',       POINTER(c_uint)),
              ('str',       POINTER(c_uint)),      
              ('repr',      POINTER(c_uint)),          
              ('let',       POINTER(c_uint)),                 
              ('get',       POINTER(c_uint)),
              ('items',     POINTER(c_uint)),
              ('keys',      POINTER(c_uint)),
              ('values',    POINTER(c_uint)),
              ('setdefault',POINTER(c_uint)),
              ('popitem',   POINTER(c_uint)),
              ('update',    POINTER(c_uint)),
              ('fromkeys',  POINTER(c_uint)),
              ('copy',      POINTER(c_uint)),                  
              ('newObj',    POINTER(c_uint)),                          
              ('zbuff',     POINTER(c_uint)),
              ('wbuff',     POINTER(c_uint)),
              ('Del',       POINTER(c_uint)),
              ('id',        c_int)]
   
class py2fbSet(Structure):
    _fields_=[('clear',               POINTER(c_uint)),
              ('In',                  POINTER(c_uint)),
              ('len',                 POINTER(c_uint)),              
              ('str',                 POINTER(c_uint)),                   
              ('repr',                POINTER(c_uint)),          
              ('let',                 POINTER(c_uint)),
              ('add',                 POINTER(c_uint)),
              ('discard' ,            POINTER(c_uint)),
              ('remove',              POINTER(c_uint)),
              ('union',               POINTER(c_uint)),              
              ('difference',          POINTER(c_uint)),
              ('intersection',        POINTER(c_uint)),              
              ('symmetric_difference',POINTER(c_uint)),
              ('issubset' ,            POINTER(c_uint)),
              ('issuperset' ,          POINTER(c_uint)),
              ('isdisjoint' ,         POINTER(c_uint)),
              ('symmetric_difference_update',POINTER(c_uint)),              
              ('difference_update',   POINTER(c_uint)),
              ('intersection_update', POINTER(c_uint)),
              ('update',              POINTER(c_uint)),                        
              ('pop',                 POINTER(c_uint)),                   
              ('copy',                POINTER(c_uint)),    
              ('newObj',              POINTER(c_uint)),                          
              ('zbuff',               POINTER(c_uint)),
              ('wbuff',               POINTER(c_uint)),
              ('Del',                 POINTER(c_uint)),
              ('id',                  c_int)]              

class pyStrBuffer:
    """ Classe ad una sola istanza"""
    _stato=dict()
    def __init__(self,dim=500):
            self._stato=self.__dict__ # nessuna altra istanza è possibile
            if 'flag' not in self._stato: # controllo se prima avvio            
                self.__dict__ ['flag']=True
                self.__dict__ ['buff']=create_unicode_buffer(dim) # creo il buffer
                self.__dict__ ['pointer']=pointer(self.__dict__ ['buff'])
                self._stato=self.__dict__ # nessuna altra istanza è possibile
    @property        
    def pBuffer(self):
        return self.__dict__['pointer']
    @property
    def buffer(self):
        return self.__dict__['buff'].value
    @buffer.setter
    def buffer(self,value):
        self.__dict__['buff'].value=value
        
class pyBytesBuffer:
    """ Classe ad una sola istanza"""
    _stato=dict()
    def __init__(self,dim=500):
        self._stato=self.__dict__ # nessuna altra istanza è possibile
        if 'flag' not in self._stato: # controllo se prima avvio
            self.__dict__ ['flag']=True
            self.__dict__ ['buff']=create_string_buffer(dim) # creo il buffer
            self.__dict__ ['pointer']=pointer(self.__dict__ ['buff'])
            self._stato=self.__dict__ # nessuna altra istanza è possibile
    @property        
    def pBuffer(self):
        return self.__dict__['pointer']
    @property
    def buffer(self):
        return self.__dict__['buff'].value
    @buffer.setter
    def buffer(self,value):
        self.__dict__['buff'].value=value

