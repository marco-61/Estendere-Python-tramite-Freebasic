# metodi dizionario
from ctypes import *
from fblib.PyObj.pybase import *
from fblib.PyObj.PyStruct import *
from fblib.PyObj.pyList import *
#from pyDict import * #PyDictExport

class dict_method:
    def __init__(self,obj,py2fbStruct,Buffer,myClass):
        self.let=obj
        self.obj=self.let.value
        self.buffer=Buffer # wstring e zstring buffer
        self.py2fbStruct=py2fbStruct
        self.myClass=myClass
        self.mem=[]
    #--------------------------pop------------------------------------
        pop=CFUNCTYPE(None,c_int,c_wchar_p,c_void_p,c_void_p)
        self.py2fbStruct.pop=cast(pop(self._pop_),POINTER(c_uint))            
    #--------------------------popitem------------------------------------
        popitem=CFUNCTYPE(None)
        self.py2fbStruct.popitem=cast(popitem(self._popitem_),POINTER(c_uint))
    #--------------------------get------------------------------------
        get=CFUNCTYPE(None,c_int,c_wchar_p,c_void_p,c_void_p)
        self.py2fbStruct.get=cast(get(self._get_),POINTER(c_uint))
    #--------------------------setdefault------------------------------------
        setdefault=CFUNCTYPE(None,c_wchar_p,c_int,c_void_p,c_void_p)
        self.py2fbStruct.setdefault=cast(setdefault(self._setdefault_),POINTER(c_uint))
    #--------------------------update------------------------------------
        update=CFUNCTYPE(None,c_wchar_p)
        self.py2fbStruct.update=cast(update(self._update_),POINTER(c_uint))
    #--------------------------keys------------------------------------
        keys=CFUNCTYPE(None,POINTER(py2fbList))
        self.py2fbStruct.keys=cast(keys(self._keys_),POINTER(c_uint))           
    #--------------------------values------------------------------------
        values=CFUNCTYPE(None,POINTER(py2fbList))
        self.py2fbStruct.values=cast(values(self._values_),POINTER(c_uint))           
    #--------------------------items------------------------------------
        items=CFUNCTYPE(None,POINTER(py2fbList))
        self.py2fbStruct.items=cast(items(self._items_),POINTER(c_uint))           
    #-------------------------Clear--------------------------------------   
        clear=CFUNCTYPE(None)
        self.py2fbStruct.clear=cast(clear(self.obj.clear),POINTER(c_uint))
    #--------------------------fromkeys------------------------------------
        fromkeys=CFUNCTYPE(None,POINTER(py2fbDict),c_wchar_p)
        self.py2fbStruct.fromkeys=cast(fromkeys(self._fromkeys_),POINTER(c_uint))
    #-----------------------------------------------------------------------        
    def _pop_(self,tipo,key,default,ptr):
        """elimina la chiave se presente e
         ritorna il valore altrimenti ritorna default"""
        self.obj=self.let.value
        p=ptr_convert(tipo,ptr)
        pdef=ptr_convert(tipo,default)
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            p[0]=self.obj.pop(key,pdef[0])
        elif tipo in (3,4):          
            v=self.obj.pop(key,pdef.value)
            self.buffer.strbuff=v # wstring ritorna in wbuff
            self.buffer.bytbuff=v.encode() # wstring ritorna in wbuff           
        elif tipo in (5,6,7,8,9):
            v=repr(self.obj.pop(key,pdef.value))
            self.buffer.strbuff=v # wstring ritorna in wbuff
            self.buffer.bytbuff=v.encode() # wstring ritorna in wbuff
                   
    def _popitem_(self):
        """elimina una chiave 
         ritorna una tupla (chiave,valore in formato wstring e zstring
         """
        self.obj=self.let.value              
        t=self.obj.popitem()
        v=repr(t)
        self.buffer.strbuff=v # wstring ritorna in wbuff
        self.buffer.bytbuff=v.encode() # wstring ritorna in wbuff      
        
    def _get_(self,tipo,key,default,ptr):
        """ritorna il valore della chiave se esiste altrimenti ritorna default"""
        self.obj=self.let.value
        p=ptr_convert(tipo,ptr)
        pdef=ptr_convert(tipo,default)
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            p[0]=self.obj.get(key,pdef[0])
        elif tipo in (3,4):          
            v=self.obj.get(key,pdef.value)
            self.buffer.strbuff=v # wstring ritorna in wbuff
            self.buffer.bytbuff=v.encode() # wstring ritorna in wbuff           
        elif tipo in (5,6,7,8,9):
            v=repr(self.obj.get(key,pdef.value))
            self.buffer.strbuff=v # wstring ritorna in wbuff
            self.buffer.bytbuff=v.encode() # wstring ritorna in wbuff            

    def _setdefault_(self,key,tipo,default,ptr):
        self.obj=self.let.value
        p=ptr_convert(tipo,ptr)        
        pdef=ptr_convert(tipo,default)        
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            p[0]=self.obj.setdefault(key,pdef[0])
        elif tipo in (3,4):
            v=self.obj.setdefault(key,pdef.value)
            self.buffer.strbuff=v # wstring ritorna in wbuff
            self.buffer.bytbuff=v.encode() # wstring ritorna in wbuff                     
        elif tipo in (5,6,7,8,9):
            v=repr(self.obj.setdefault(key,eval(pdef.value))) 
            self.buffer.strbuff=v # wstring ritorna in wbuff
            self.buffer.bytbuff=v.encode() # wstring ritorna in wbuff
            
    def _update_(self,iteratore):
        self.obj=self.let.value
        t=eval(iteratore)
        self.obj.update(t)
        
    def _fromkeys_(self,buffer,iteratore):
        self.obj=self.let.value
        t=eval(iteratore)
        d=self.obj.fromkeys(*t)  
        self.mem.append(self.myClass(d)) # creo un nuovo oggetto
        memmove(buffer,byref(self.mem[-1].getObj),sizeof(py2fbDict))#copio il descrittore
    def _keys_(self,buffer):
        self.obj=self.let.value
        t=list(self.obj.keys())
        self.mem.append(PyListExport(t)) # creo un nuovo oggetto
        memmove(buffer,byref(self.mem[-1].getObj),sizeof(py2fbList))#copio il descrittore
        
    def _values_(self,buffer):
        self.obj=self.let.value
        t=list(self.obj.values())
        self.mem.append(PyListExport(t)) # creo un nuovo oggetto
        memmove(buffer,byref(self.mem[-1].getObj),sizeof(py2fbList))#copio il descrittore
        
    def _items_(self,buffer):
        self.obj=self.let.value
        t=list(self.obj.items())
        self.mem.append(PyListExport(t)) # creo un nuovo oggetto
        memmove(buffer,byref(self.mem[-1].getObj),sizeof(py2fbList))#copio il descrittore   

    def _contains_(self,key): # versione per dizionari
        self.obj=self.let.value        
        return key in self.obj
