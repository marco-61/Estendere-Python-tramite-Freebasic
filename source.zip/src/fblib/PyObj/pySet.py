from fblib.PyObj.pybase import *
from fblib.PyObj.contains import *
from fblib.PyObj.set_method import *
class PySetExport(Contains):
    _mem={}
    def __init__(self,Set=set()):       
        super().__init__(Set,set,py2fbSet,PySetExport,self._mem)
        #----------------------------------------------------        
        self.toString=toString(self.let,self.py2fbStruct,self.buffer)
        self.len=Len(self.let,self.py2fbStruct)
        self.contains=contains(self.let,self.py2fbStruct,True)        
        self.copy_clear=copy_clear(self.let,self.py2fbStruct,PySetExport,self.ClassPtr,self._mem)          
        self.set_method=set_method(self.let,self.py2fbStruct,self.buffer,PySetExport,set,self.ClassPtr)
        self.newObj=newObj(self.let,self.py2fbStruct,PySetExport,set,self.ClassPtr,self._mem)   
        self.Del=Del(self._mem,self.py2fbStruct)
