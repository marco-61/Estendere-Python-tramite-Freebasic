from ctypes import *
from fblib.PyObj.PyStruct import *
from fblib.PyObj.pybase import ptr_convert

class set_method:
    def __init__(self,obj,py2fbStruct,Buffer,myClass,mytype,ClassPtr):
        self.let=obj
        self.obj=self.let.value
        self.buffer=Buffer # wstring buffer e zstring buffer
        self.py2fbStruct=py2fbStruct
        self.myClass=myClass
        self.mytype=mytype
        self.ClassPtr=ClassPtr
        self.mem=[]
        #--------------------------pop------------------------------------
        pop=CFUNCTYPE(None,c_int,c_int,c_void_p)
        self.py2fbStruct.pop=cast(pop(self._pop_),POINTER(c_uint))       
       #--------------------------add-----------------------------------
        add=CFUNCTYPE(None,c_int,c_void_p)
        self.py2fbStruct.add=cast(add(self._add_),POINTER(c_uint))       
       #--------------------------discard-----------------------------------
        discard=CFUNCTYPE(None,c_int,c_void_p)
        self.py2fbStruct.discard=cast(discard(self._discard_),POINTER(c_uint))       
       #--------------------------remove-----------------------------------
        remove=CFUNCTYPE(None,c_int,c_void_p)
        self.py2fbStruct.remove=cast(remove(self._remove_),POINTER(c_uint))  
       #--------------------------union-----------------------------------
        union=CFUNCTYPE(None,POINTER(py2fbSet),c_wchar_p)
        self.py2fbStruct.union=cast(union(self._union_),POINTER(c_uint))  
       #--------------------------difference-----------------------------------
        difference=CFUNCTYPE(None,POINTER(py2fbSet),c_wchar_p)
        self.py2fbStruct.difference=cast(difference(self._difference_),POINTER(c_uint))  
       #--------------------------intersection-----------------------------------
        intersection=CFUNCTYPE(None,POINTER(py2fbSet),c_wchar_p)
        self.py2fbStruct.intersection=cast(intersection(self._intersection_),POINTER(c_uint))  
       #--------------------------symmetric_difference-----------------------------------
        symmetric_difference=CFUNCTYPE(None,POINTER(py2fbSet),c_wchar_p)
        self.py2fbStruct.symmetric_difference=cast(symmetric_difference(self._symmetric_difference_),POINTER(c_uint))  
       #--------------------------isubset-----------------------------------
        isubset=CFUNCTYPE(c_bool,c_wchar_p)
        self.py2fbStruct.isubset=cast(isubset(self._isubset_),POINTER(c_uint))  
       #--------------------------issuperset-----------------------------------
        issuperset=CFUNCTYPE(c_bool,c_wchar_p)
        self.py2fbStruct.issuperset=cast(issuperset(self._issuperset_),POINTER(c_uint))  
       #--------------------------isdisjoint-----------------------------------
        isdisjoint=CFUNCTYPE(c_bool,c_wchar_p)
        self.py2fbStruct.isdisjoint=cast(isdisjoint(self._isdisjoint_),POINTER(c_uint))  
       #-----------------------symmetric_difference_update------------------------
        symmetric_difference_update=CFUNCTYPE(None,c_wchar_p)
        self.py2fbStruct.symmetric_difference_update=cast(symmetric_difference_update(self._symmetric_difference_update_),POINTER(c_uint))  
       #-----------------------symmetric_update------------------------
        symmetric_update=CFUNCTYPE(None,c_wchar_p)
        self.py2fbStruct.symmetric_update=cast(symmetric_update(self._symmetric_update_),POINTER(c_uint))  
       #----------------------------update------------------------
        update=CFUNCTYPE(None,c_wchar_p)
        self.py2fbStruct.update=cast(update(self._update_),POINTER(c_uint))  

    def _pop_(self,tipo,ptr):
        self.obj=self.let.value
        p=ptr_convert(tipo,ptr)
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            p[0]=self.obj.pop(index)
        elif tipo in (3,4):
            self.buffer.strbuff=self.obj.pop(index)
            self.buffer.bytbuff=self.obj.pop(index)            
        elif tipo in (5,6,7,8,9):
            self.buffer.strbuff=repr(self.obj.pop(index))
            self.buffer.bytbuff=repr(self.obj.pop(index))
            
    def _add_(self,tipo,ptr):
        self.obj=self.let.value
        p=ptr_convert(tipo,ptr)
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            self.obj.add(p[0])
        elif tipo in (3,4):
            self.obj.add(p.value)         
        elif tipo in (5,6,7,8,9):
            self.obj.add(eval(p.value))

    def _discard_(self,tipo,ptr):
        self.obj=self.let.value
        p=ptr_convert(tipo,ptr)
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            self.obj.discard(p[0])
        elif tipo in (3,4):
            self.obj.discard(p.value)         
        elif tipo in (5,6,7,8,9):
            self.obj.discard(eval(p.value))

    def _remove_(self,tipo,ptr):
        self.obj=self.let.value
        p=ptr_convert(tipo,ptr)
        # Controlla prima se l'elemento è presente per evitare errori
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            if not p[0] in self.obj: return
            t=p[0]
        elif tipo in (3,4):
            if not p.value in self.obj:return
            t=p.value            
        elif tipo in (5,6,7,8,9):
            t=eval(p.value)
            if not t in self.obj:return
        self.obj.remove(t)
    def _union_(self,buffer,ptr):
        self.obj=self.let.value
        t=eval(ptr) #valuta ls stringa
        t2=self.obj.union(t)       
        self.mem.append(self.myClass(t2))
        memmove(buffer,byref(self.mem[-1].getObj),sizeof(self.py2fbStruct)) # copio il descrittore

    def _difference_(self,buffer,ptr):
        self.obj=self.let.value
        t=eval(ptr) #valuta ls stringa
        t2=self.obj.difference(t)
        self.mem.append(self.myClass(t2))
        memmove(buffer,byref(self.mem[-1].getObj),sizeof(self.py2fbStruct)) # copio il descrittore            

    def _intersection_(self,buffer,ptr):
        self.obj=self.let.value
        t=eval(ptr) #valuta ls stringa
        t2=self.obj.intersection(t)            
        self.mem.append(self.myClass(t2))
        memmove(buffer,byref(self.mem[-1].getObj),sizeof(self.py2fbStruct)) # copio il descrittore

    def _symmetric_difference_(self,buffer,ptr):
        self.obj=self.let.value
        t=eval(ptr) #valuta ls stringa
        t2=self.obj.symmetric_difference(t)            
        self.mem.append(self.myClass(t2))
        memmove(buffer,byref(self.mem[-1].getObj),sizeof(self.py2fbStruct)) # copio il descrittore

    def _isubset_(self,ptr):
        self.obj=self.let.value
        s=eval(ptr)
        return self.obj.isubset(s)

    def _issuperset_(self,ptr):
        self.obj=self.let.value
        s=eval(ptr)
        return self.obj.issuperset(s)

    def _isdisjoint_(self,ptr):
        self.obj=self.let.value
        s=eval(ptr)
        return self.obj.isdisjoint(s)

    def _symmetric_difference_update_(self,ptr):
        self.obj=self.let.value
        s=eval(ptr)
        self.obj.symmetric_difference_update(s)

    def _symmetric_update_(self,ptr):
        self.obj=self.let.value
        s=eval(ptr)
        self.obj.symmetric_update(s)

    def _update_(self,ptr):
        self.obj=self.let.value
        s=eval(ptr)
        self.obj.update(s)                
    
