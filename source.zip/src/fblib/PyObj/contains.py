from fblib.PyObj.pybase import *

class Contains:
    def __init__(self,value,mytype,py2fbStruct,myClass,mem):
        if not isinstance(value,mytype):value=mytype() # validazione del tipo
        self.mytype=mytype
        self._mem=mem #dizionario persistenza degli oggetti
        self.py2fbStruct=py2fbStruct() #crea la struttura contenitore
        if len(self._mem)>0:
            self.py2fbStruct.id=len(self._mem)-1
        else:
            self.py2fbStruct.id=-1
        self.myClass=myClass
        self.let=let(value,self.py2fbStruct) # oggetto let
        self.ClassPtr=POINTER(py2fbStruct) # puntatore alla struttura
        self.buffer=buffer(self.let,self.py2fbStruct) #buffer str e bytes
     
    @property
    def getObj(self): # ritorna l'oggetto Freebasic
        return self.py2fbStruct
    @property
    def value(self):# ritorna il valore attuale
        return self.let.value
    @value.setter
    def value(self,value):# modifica l'oggetto da Python
        self.let.value=value
    def __len__(self): # numero di elementi creati da Freebasic
        return len(self._mem)
    def __getitem__(self, item): # ritorna un oggetto creato da Freebasic
        return self._mem[item]
    def keys(self):
        return self._mem.keys()
    def values(self):
        return self._mem.values()    
    def items(self):
        return self._mem.items()
