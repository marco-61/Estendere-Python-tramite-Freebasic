from ctypes import *
@CFUNCTYPE(None,c_int,c_void_p)
def callback(tipo, ptr):
    if tipo==0: # bool
        p=cast(ptr,POINTER(c_bool)) #cast puntatore
        print(f"Ricevuto un bool {p[0]}")
        p[0]=not p[0]
    elif tipo==1: # int
        p=cast(ptr,POINTER(c_int)) #cast puntatore
        print(f"Ricevuto un intero {p[0]}")
        p[0]=999
    elif tipo==2: # float
        p=cast(ptr,POINTER(c_float)) #cast puntatore
        print(f"Ricevuto un float {p[0]}")
        p[0]=999.9
    elif tipo==3: # zstring
        p=cast(ptr,c_char_p) #cast puntatore        
        print(f"Ricevuto una zstring {p.value}")
    elif tipo==4: # wstring
        p=cast(ptr,c_wchar_p) #cast puntatore                
        print(f"Ricevuto una wtring {p.value}")
      
lib=CDLL(r'.\test_param.dll')
lib.test.argtypes=[c_void_p]
lib.test(callback)
input('premi enter per uscire')
      
