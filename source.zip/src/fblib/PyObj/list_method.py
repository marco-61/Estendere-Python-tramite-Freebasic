from ctypes import *
from fblib.PyObj.PyStruct import *
from fblib.PyObj.pybase import ptr_convert
class list_method:
    def __init__(self,obj,py2fbStruct,Buffer,myClass):
        self.let=obj
        self.obj=self.let.value
        self.buffer=Buffer # wstring buffer e zstring buffer
        self.py2fbStruct=py2fbStruct
        self.myClass=myClass
        #------------------------sort---------------------------------------
        sort=CFUNCTYPE(None,c_bool)
        self.py2fbStruct.sort=cast(sort(self._sort_),POINTER(c_uint))            
        #-------------------------Append----------------------------------------
        append=CFUNCTYPE(None,c_int,c_void_p)
        self.py2fbStruct.append=cast(append(self._append_),POINTER(c_uint)) 
        #--------------------------pop------------------------------------
        pop=CFUNCTYPE(None,c_int,c_int,c_void_p)
        self.py2fbStruct.pop=cast(pop(self._pop_),POINTER(c_uint))       
        #--------------------------Remove------------------------------
        remove=CFUNCTYPE(None,c_int,c_void_p)
        self.py2fbStruct.remove=cast(remove(self._remove_),POINTER(c_uint))
        #-------------------------Insert---------------------------------
        insert=CFUNCTYPE(None,c_int,c_int,c_void_p)
        self.py2fbStruct.insert=cast(insert(self._insert_),POINTER(c_uint))     
        #-------------------------Reverse---------------------------------------   
        reverse=CFUNCTYPE(None)
        self.py2fbStruct.reverse=cast(reverse(self._reverse_),POINTER(c_uint))    
        
    def _sort_(self,reverse):
        self.obj=self.let.value        
        self.obj.sort(reverse=reverse)
        
    def _append_(self,tipo,ptr):
        self.obj=self.let.value        
        p=ptr_convert(tipo,ptr)
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            self.obj.append(p[0])
        elif tipo in (3,4):
            self.obj.append(p.value)
        elif tipo in (5,6,7,8,9):    
            self.obj.append(eval(p.value))
            
    def _pop_(self,tipo,index,ptr):
        self.obj=self.let.value
        p=ptr_convert(tipo,ptr)
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            p[0]=self.obj.pop(index)
        elif tipo in (3,4):
            self.buffer.strbuff=self.obj.pop(index)
            self.buffer.bytbuff=self.obj.pop(index)            
        elif tipo in (5,6,7,8,9):
            self.buffer.strbuff=repr(self.obj.pop(index))
            self.buffer.bytbuff=repr(self.obj.pop(index))        
            
    def _remove_(self,tipo,ptr):
        self.obj=self.let.value
        p=ptr_convert(tipo,ptr)
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            self.obj.remove(p[0])
        elif tipo in (3,4):
            self.obj.remove(p.value)      
        elif tipo in (5,6,7,8,9):    
            self.obj.remove(eval(p.value))
            
    def _insert_(self,tipo,index,ptr):
        self.obj=self.let.value
        p=ptr_convert(tipo,ptr)
        if tipo in (0,1,2,10,11,12,13,14,15,16,17):
            self.obj.insert(index,p[0])
        elif tipo in (3,4):
            self.obj.insert(index,p.value)
        elif tipo in (5,6,7,8,9):    
            self.obj.insert(index,eval(p.value))

    def _reverse_(self,reverse):
        self.obj=self.let.value        
        self.obj.sort(reverse=reverse)
