from ctypes import *
from fblib.PyObj.pybase import *
from fblib.PyObj.contains import *
from fblib.PyObj.dict_method import *

class PyDictExport(Contains):
    _mem={}
    def __init__(self,Dict={}):
        super().__init__(Dict,dict,py2fbDict,PyDictExport,self._mem)  
        #----------------------------------------------------  
        self.is_type =is_type(self.let,self.py2fbStruct,False)
        self.getitem=getitem(self.let,self.py2fbStruct,self.buffer,False)
        self.setitem=setitem(self.let,self.py2fbStruct,False)
        self.delitem=delitem(self.let,self.py2fbStruct,False)        
        self.toString=toString(self.let,self.py2fbStruct,self.buffer)
        self.contains=contains(self.let,self.py2fbStruct,False)        
        self.len=Len(self.let,self.py2fbStruct)
        self.copy_clear=copy_clear(self.let,self.py2fbStruct,PyDictExport,self.ClassPtr,self._mem)  
        self.dict_method=dict_method(self.let,self.py2fbStruct,self.buffer,PyDictExport)        
        self.newObj=newObj(self.let,self.py2fbStruct,PyDictExport,dict,self.ClassPtr,self._mem)                         
        self.Del=Del(self._mem,self.py2fbStruct)
