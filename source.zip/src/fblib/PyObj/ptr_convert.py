def ptr_convert(tipo, ptr):
    if tipo==0: #Bool
        p=cast(ptr,POINTER(c_bool)) #cast puntatori
    elif tipo==1:#int
        p=cast(ptr,POINTER(c_int))
    elif tipo==2:#float
        p=cast(ptr,POINTER(c_float)) 
    elif tipo==3:#float
        p=cast(ptr,POINTER(c_char_p)) 
    elif tipo in (4,5,6,7,8,9):#wstring
        p=cast(ptr,POINTER(c_wchar_p))
    elif tipo==3:#float
        p=cast(ptr,POINTER(c_char_p))
    elif tipo==10:#double
        p=cast(ptr,POINTER(c_double))
    elif tipo==11:#long
        p=cast(ptr,POINTER(c_long))
    elif tipo==12:#Ulong
        p=cast(ptr,POINTER(c_ulong))        
    elif tipo==13:#Byte
        p=cast(ptr,POINTER(c_byte)) #cast puntatore
    elif tipo==14:#UByte
        p=cast(ptr,POINTER(c_ubyte)) #cast puntatore
    elif tipo==15:#short
        p=cast(ptr,POINTER(c_short)) #cast puntatore
    elif tipo==16:#ushort
        p=cast(ptr,POINTER(c_ushort)) #cast puntatore
    elif tipo==17:#uint
        p=cast(ptr,POINTER(c_uint)) #cast puntatore
    return p    
