from fblib.PyObj import *
from fblib.PyObj.pybase import *
from fblib.PyObj.contains import *
class PyTupleExport(Contains):
    _mem={}
    def __init__(self,tupla=()):
        super().__init__(tupla,tuple,py2fbTuple,PyTupleExport,self._mem)
        #------------------------------------------------------------                 
        self.is_type =is_type(self.let,self.py2fbStruct,True)
        self.getitem=getitem(self.let,self.py2fbStruct,self.buffer,True)
        self.count_index=count_index(self.let,self.py2fbStruct)        
        self.contains=contains(self.let,self.py2fbStruct,True)
        self.count_index=count_index(self.let,self.py2fbStruct)        
        self.slice=Slice(self.let,self.py2fbStruct,PyTupleExport,self._mem)
        self.toString=toString(self.let,self.py2fbStruct,self.buffer)
        self.len=Len(self.let,self.py2fbStruct)        
        self.newObj=newObj(self.let,self.py2fbStruct,PyTupleExport,tuple,self.ClassPtr,self._mem)                 
        self.Del=Del(self._mem,self.py2fbStruct)
