from fblib.fbConsole.Entry import *

class MEdit:
    def __init__(self):
        self._stack,self._i=[],0   
    def add(self,entry):
        entry['multi_edit']=True # modalita multi edit
        self._stack.append(entry)
    def is_mouse_over(self):
        for i,o in enumerate(self._stack):
            if o.is_mouse_over(): self._i=i;return True
        return False    
    def is_mouse_click(self,button):
        for i,o in enumerate(self._stack):
            if o.is_mouse_click(button): self._i=i;return True
        return False            
    def action(self):
        self._loop=True
        while self._loop: 
            c=self._stack[self._i].input()
            if c==I_UP:
                if self._i==0: self._i=len(self._stack)-1
                else: self._i-=1
            elif c==I_DOWN or c==I_TAB:
                if self._i==len(self._stack)-1:self._i=0
                else: self._i+=1
            elif c==I_ESCAPE or c==I_ENTER:
                self._loop=False        
                return c #codice di uscita
