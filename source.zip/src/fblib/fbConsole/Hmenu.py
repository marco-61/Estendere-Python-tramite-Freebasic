from fblib.fbConsole.Screen import Screen
from fblib.fbConsole.Write import *
from fblib.fbTypes import *
from fblib.Costant import *
from fblib.fbConsole.Widgets import *
from fblib.fbConsole.Label import *
class Hmenu:
    def __init__(self,parent,row,col,**kargs):
        self._stack, self._ind=[],0
        self._parent=parent
        self._row=row
        self._col=col        
        self._term=parent.term
        self._var=kargs
        self._var['visible']=False # forza non visibile
        if "escape" not in self._var: self._var["escape"]=False
    def is_mouse_over(self):
        for i,o in enumerate(self._stack):
            if o.is_mouse_over(): return True
        return False    
    def is_mouse_click(self,button):
        for i,o in enumerate(self._stack):
            if o.is_mouse_click(button):
                self._stack[self._ind].reverse()
                o.reverse()
                self._ind=i
                return True
        return False                        
    def choise(self,label,func):
        self._var['text']=label
        self._var['command']=func
        self._var['width']=len(label)
        self._stack.append(Label(self._parent,self._row,self._col+self._ind,**self._var))
        self._ind+=len(label)+2
    def space(self):
        self._ind+=1
    def paint(self):
        for l in self._stack:
            l['visible']=True;
            l.paint()            
    def select(self,dummy=0):
        self.paint()
        self._ind=0 #indice
        self._stack[self._ind].reverse()
        loop=True
        while loop:
            m=self._term.getmouse()
            s=self._term.inkey()# controllo keyboard
            if s==I_ESCAPE:
                if self._var["escape"]==True:
                    loop=False
            elif s==I_ENTER:
                self._stack[self._ind].reverse()  
                self._stack[self._ind].action(self._ind) #esegui
                self._stack[self._ind].reverse()
            elif s==I_DOWN:
                self._stack[self._ind].action(self._ind) #esegui
            elif s==I_LEFT:         
                if self._ind >0:
                        self._stack[self._ind].reverse()
                        self._ind-=1
                        self._stack[self._ind].reverse()
                else:
                    self._stack[self._ind].reverse()
                    self._ind=len(self._stack)-1
                    self._stack[self._ind].reverse()
            elif s==I_RIGHT:
                if self._ind < len(self._stack):
                        self._stack[self._ind].reverse()                        
                        self._ind+=1          
                        if self._ind==len(self._stack):
                            self._ind=0
                            self._stack[self._ind].reverse()
                        else:      
                            self._stack[self._ind].reverse()          
            elif s==I_HOME:           
                self._stack[self._ind].reverse()
                self._ind=0
                self._stack[self._ind].reverse()          
            elif s==I_END:              
                self._stack[self._ind].reverse()
                self._ind=len(self._stack)- 1           
                self._stack[self._ind].reverse()
            else:
                if self.is_mouse_click(1):
                    self._stack[self._ind].action(self._ind)                    
                elif not self.is_mouse_over() and self.is_mouse_click(1):
                    loop=False
                    break

                  
                            
                                 
            
