from fblib.fbConsole.fbConsole import *
from fblib.Costant import *
from fblib.fbConsole.WinBase import *
from fblib.fbConsole.Write import *
from string import ascii_lowercase,ascii_uppercase,digits,punctuation
from abc import ABCMeta, abstractmethod


class Widgets(metaclass=ABCMeta):
    def __init__(self,parent,row,col,**kargs):
        self._parent=parent
        self._term=self._parent.term
        self._row,self._col,=row,col
        self._var=kargs
        self._var['row']=row; self._var['col']=col
        if 'height' not in self._var: self._var['height']= 2 
        if 'width'  not in self._var : self._var['width']=10 
        if 'text'   not in self._var : self._var['text']='' 
        if 'fg'     not in self._var : self._var['fg']=LGREY 
        if 'bg'     not in self._var : self._var['bg']=BLACK
        if 'active_fg' not in self._var : self._var['active_fg']=self._var['fg']
        if 'active_bg' not in self._var : self._var['active_bg']=self._var['bg']
        if 'disable_fg' not in self._var : self._var['disable_fg']=LGREY
        if 'disable_bg' not in self._var : self._var['disable_bg']=self._var['bg']
        if 'disable' not in self._var : self._var['disable']=False
        if 'visible' not in self._var : self._var['visible']=True        
        if 'relief' not in self._var: self._var['relief']='SINGLE'        
        if 'command'not in self._var:
            self._command=None
        else:
            self._command=self._var['command']; del(self._var['command'])            
        if 'repaint'not in self._var:
            self._repaint=None
        else:
            self._repaint=self._var['repaint']; del(self._var['repaint'])        
        self._buffer=self._term.newArea(self._var['height'],self._var['width']) # crea il buffer per il Widgets
        t=self._term.get(self._buffer,self._row_,self._col_)# salva l'area destinata al widget
        self._buffer2=None

        
    @property
    def term(self):
        return self._term
    def __deallocateArea__(self):
        if self._var['visible']:
            t=self._term.put(self._buffer,self._row_,self._col_) #ripristina l'area
        else:    
            self._term.deallocateArea(self._buffer2)
        self._term.deallocateArea(self._buffer)      
    def hide(self):
        if self.isVisible():
            self._buffer2=self._term.newArea(self._var['height'],self._var['width'])# nuovo buffer
            t=self._term.get(self._buffer2,self._row_,self._col_)# salva la finestra
            t=self._term.put(self._buffer,self._row_,self._col_)# ripristina lo sfondo
            self._var['visible']=False
    def show(self):
        if not self.isVisible():
            t=self._term.put(self._buffer2,self._row_,self._col_)# ripristina la finestra            
            self._term.deallocateArea(self._buffer2)# cancella il buffer
            self._buffer2=None
            self._var['visible']=True
    def move(self,row,col):
        self.hide()
        self._var['row']=row;self._var['col']=col # nuova posizione
        t=self._term.get(self._buffer,self._row_,self._col_)# salva l'area destinata al widget
        self.show()
    def isVisible(self):
        return self._var['visible']
    def isDisable(self):
        return self._var['disable']        
    def _color_(self): #ritorna i colori appropriati
        fg=self._var['disable_fg'] if self.isDisable() else self._var['active_fg']
        bg=self._var['disable_bg'] if self.isDisable() else self._var['active_bg']
        return (fg,bg)
    def paint(self):
        row=self._row_-1
        col=self._col_-1
        fg,bg=self._color_()
        self._term.clear_area(row,col,self._var['height'],self._var['width']+1,fg=fg,bg=bg)
        self._term.box(row,col,self._var['height'],self._var['width'],relief=self._var['relief'])    
    def  repaint(self,*args,**kargs):
        if self._repaint is not None:self._repaint(*args,**kargs) # chiama la funzione di repaint
    def action(self,*args,**kargs):
        if not self.isDisable(): # se non disabilitata
            if self._command is not None:self._command(*args,**kargs) # chiama la funzione di associata   se esiste     
    def __getitem__(self,key):
        if key in self._var:
            return self._var[key]
        else:
            raise KeyError('Chiave non presente')                                                                  
    def __setitem__(self,key,value):
        self._var[key]=value                                                                  
    def __delitem__(self,key):
        if key in self._var: del(self._var[key]) # cancella la chiave se presente                                                                         
    def border(self):
        self._var['relief']='DOUBLE' if self._var['relief']=='SINGLE' else 'SINGLE'
        self.paint()
    def is_mouse_over(self):
        row=self._parent['row']+self._var['row']-1
        col=self._parent['col']+self._var['col']-1
        return self._term.mouse_over(row,col,self._var['height'],self._var['width'])
    def is_mouse_click(self,button):
        row=self._row_ -2
        col=self._col_ 
        return self._term.mouse_click(button,row,col,self._var['height'],self._var['width'])
    @property
    def _row_(self):
        return self._parent['row']+self._var['row']
    @property
    def _col_(self):
        return self._parent['col']+self._var['col']
    def reverse(self):
        if not self._var['disable']: # se non disabilitata
            tmp,self._var['active_fg']=self._var['active_fg'],self._var['active_bg']
            self._var['active_bg']=tmp
            self.paint()    
    def restore(self):
        self._var['active_bg']=self._var['bg']
        self._var['active_fg']=self._var['fg']
