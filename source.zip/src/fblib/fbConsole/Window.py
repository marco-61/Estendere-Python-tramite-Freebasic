# class Window finestre per console
from fblib.fbConsole.fbConsole import *
from fblib.Costant import *
from fblib.fbConsole.WinBase import *
class Window(WinBase):
    def __init__(self,term,row,col,height,width,title='',relief='SINGLE',fg=LGREY,bg=BLACK ,repaint=None):
        super().__init__(term,row,col,height,width,title=title,relief=relief,fg=fg,bg=bg ,repaint=repaint)
        if 'visible'     not in self._var : self._var['visible']=True           
        self._buffer=self._term.newArea(self._var['height'],self._var['width']) # crea il buffer per la finestra
        self._buffer2=None
        t=self._term.get(self._buffer,self._var['row'],self._var['col'])# salva l'area destinata alla finestra
        self._repaint=repaint
        self.paint()
    @property
    def term(self):
        return self._term
    def __deallocateArea__(self):
        if self._var['visible']:
            t=self._term.put(self._buffer,self._var['row'],self._var['col']) #riristina l'area
        else:    
            self._term.deallocateArea(self._buffer2)
        self._term.deallocateArea(self._buffer)          
    def hide(self):
        if self.isVisible():
            self._buffer2=self._term.newArea(self._var['height'],self._var['width'])# nuovo buffer
            t=self._term.get(self._buffer2,self._var['row'],self._var['col'])# salva la finestra
            t=self._term.put(self._buffer,self._var['row'],self._var['col'])# ripristina lo sfondo
            self._var['visible']=False
    def show(self):
        if not self.isVisible():
            t=self._term.put(self._buffer2,self._var['row'],self._var['col'])# ripristina la finestra            
            self._term.deallocateArea(self._buffer2)# cancella il buffer
            self._buffer2=None
            self._var['visible']=True            
    def move(self,row,col):
        self.hide()
        self._var['row']=row;self._var['col']=col # nuova posizione
        t=self._term.get(self._buffer,self._var['row'],self._var['col'])# salva l'area destinata alla finestra
        self.show()
    def isVisible(self):
        return self._var['visible']
    def paint(self):
        self._term.clear_area(self._var['row'],self._var['col'],self._var['height'],
                    self._var['width'],fg=self._var['fg'],bg=self._var['bg'])
        self._term.box(self._var['row'],self._var['col'],self._var['height'],self._var['width'],relief=self._var['relief'],title=self._var['title'])
    def is_mouse_over(self):
        row=self._parent['row']+self._var['row']-1
        col=self._parent['col']+self._var['col']
        return self._term.mouse_over(row,col,self._var['height'],self._var['width'])
    def is_mouse_click(self,button):
        row=self._parent['row']+self._var['row']-1
        col=self._parent['col']+self._var['col']        
        return self._term.mouse_click(button,row,col,self._var['height'],self._var['width'])

# dealloca il buffer della finestra e cancella il riferimento 
def kill(obj):
   b=dir(obj) #Controllo la presenza del magic method
   if '__deallocateArea__' in b:#dealloca il buffer
       obj.__deallocateArea__()
   del(obj) # elimina l'oggetto    
