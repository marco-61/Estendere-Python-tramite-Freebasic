from fblib.fbConsole.fbConsole import *

class ScreenBuff:
    def __init__(self,term):
        self._term=term
        self._buff=[]
    def new(self):
        h=self._term.lines()-1
        w=self._term.columns()-1
        self._buff.append(self._term.newArea(h,w))
    def get(self,buff):
        if buff in range(1,len(self._buff)+1):#i buffer iniziano da 1
            buff-=1 #indice reale
            self._term.get(self._buff[buff],1,1)
        else: raise(IndexError,'Buffer no exist')
    def put(self,buff):
        if buff in range(1,len(self._buff)+1):#i buffer iniziano da 1
            buff-=1 #indice reale
            self._term.put(self._buff[buff],1,1)
        else: raise(IndexError,'Buffer no exist')                       
    def delBuff(self,buff):
        if buff in range(1,len(self._buff)+1):#i buffer iniziano da 1
            buff-=1 #indice reale
            self._term.deallocateArea(self._buff[buff])
        else: raise(IndexError,'Buffer no exist')
    def delAll(self):
        for buff in self._buff:
            self._term.deallocateArea(buff)
            
