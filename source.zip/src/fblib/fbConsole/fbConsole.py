#-------------------------------------------------------------------------------
# Name:        fbConsole.py
# Purpose:     Wrapper FreeBasic Console Library
#
# Author:      Marco Salvati
#
# Created:     14/04/2019
# Copyright:   (c) Marco Salvati 2019
# Licence:     GPL v.3
# Versione:    1.9
#-------------------------------------------------------------------------------
from fblib.fbTypes import *
from fblib.Costant import *
import os
FBCONSOLE_PATH=r"C:\Users\Utente\AppData\Local\Programs\Python\Python39\Lib\site-packages\fblib\fbConsole\dll\fbConsole.dll"
class fbConsole:
    def __init__(self):
        self._fbl=cdll.LoadLibrary(FBCONSOLE_PATH)       
        self._pos=()
        self._fg,self._bg=LGREY,BLACK # colori standart
        self._X,self._Y,self._Buttons,self._Wheel,self._visibility,self._Clip=c_int(0),c_int(0),c_int(0),c_int(0),c_int(0),c_int(0)
        self.actual=(LGREY,BLACK)
        self.set_color(LGREY,BLACK)
        self._width=self.width() # dimensioni dello schermo
        self.cornici={'SINGLE':'┌┐│─└┘├┤┴┬┼','DOUBLE':'╔╗║═╚╝╠╣╩╦╬'}#cornici delle finestre        
    def cls(self,mode=0):
        self._fbl.fbCls.argtypes=[c_int]
        self._fbl.fbCls(c_int(mode))
    clear=cls  # alias
    def LoByte(self,n):
        self._fbl.fbLoByte.argtypes=[c_int]
        self._fbl.fbLoByte.restype=c_int
        return self._fbl.fbLoByte(c_int(n))
    def HiByte(self,n):
        self._fbl.fbLHiByte.argtypes=[c_int]
        self._fbl.fbHiByte.restype=c_int
        return self._fbl.fbLowByte(c_int(n))
    def LoWord(self,n):
        self._fbl.fbLoWord.argtypes=[c_int]
        self._fbl.fbLoWord.restype=c_int
        return self._fbl.fbLoWord(c_int(n))
    def HiWord(self,n):
        self._fbl.fbHiWord.argtypes=[c_int]
        self._fbl.fbHiWord.restype=c_int
        return self._fbl.fbHiWord(c_int(n))                                     
    def width(self,col=-1,row=-1):
        self._fbl.fbWidthGet.restype = c_int
        rc=self._fbl.fbWidthGet()
        if col > -1 and row >-1:
            self._fbl.fbWidthSet.argtypes=[c_int,c_int]
            self._fbl.fbWidthSet(c_int(col),c_int( row))
            self._width=(col,row)
            return 
        r=self.HiWord(rc)
        c=self.LoWord(rc)
        self._width=(c,r)
        return (c,r)
    def columns(self):
        return self._width[0]
    def lines(self):
        return self._width[1]
    @property
    def cursorY(self):
        self._fbl.fbCursorY.restype = c_int
        return self._fbl.fbCursorY()
    @property    
    def cursorX(self):
        self._fbl.fbCursorX.restype = c_int
        return self._fbl.fbCursorX()
    def locate(self,row,col,cursorState=1):
        self._fbl.fbLocate.argtypes=[c_int,c_int,c_int]
        self._fbl.fbLocate(c_int(row),c_int(col),c_int(cursorState))
    def save_pos(self):
        self._pos=(self.cursorY(),self.cursorX)
    def restore_pos(self):
        self.Locate(self._pos[0],self._pos[1])
    def reset(self):
        self.set_color(LGREY,BLACK)
    def set_color(self, fg=None, bg=None):
        self._fbl.fbColor.argtypes=[c_int,c_int]       
        fg=fg if fg is not None else self.actual[0]
        bg=bg if bg is not None else self.actual[1]
        self._fbl.fbColor(c_int(fg),c_int(bg))
        self.actual=(fg,bg) #colori attuali
    def color(self):
        return  self.actual
    def getcolor(self):
        self._fbl.fbGetColor.restype=c_uint
        c=self._fbl.fbGetColor()
        return (self.HiWord(c),self.LoWord(c)) # tupla (foreground,background)
    
    def screen(self,row,col,colorflag=0):
        self._fbl.fbScreen.restype = c_int
        self._fbl.fbScreen.argtypes=[c_int,c_int,c_int]
        rc=self._fbl.fbScreen(row,col,colorflag)
        if colorflag>0: # colorflag : 0 codice ascii,1 colore  ritorna tupla stile Python (fg,bg)
           rc= (rc & 15,rc >> 4) 
        return rc
    def sleep(self,amount=-1,flag=0):
        self._fbl.fbSleep.argtypes=[c_int,c_int]       
        self._fbl.fbSleep(c_int(amount),c_int(flag))
    def print(self,text):
        if isinstance(text,bytes):
            t=text.decode()
        elif not isinstance(text,str):
            t=str(text)
        t=c_wchar_p(str(text))
        self._fbl.fbWPrint.argtypes=[c_wchar_p]            
        self._fbl.fbWPrint(t)                
    def print_at(self,row,col,text):      
        self.locate(row,col)
        self.print(text)
    def cprint(self,fg,bg,text):       
        oc=self.set_color(fg,bg)
        self.print(text)        
    def lprint(self, text):
        if isinstance(text,bytes):
            t=text.decode()
        elif not isinstance(text,str):
            t=str(text)
        t=c_wchar_p(str(t))
        self._fbl.fbWLPrint.argtypes=[c_wchar_p]            
        self._fbl.fbWLPrint(t)
        
    def move_left(self,c=1):
        row=self.cursorY
        col=self.cursorX
        self.locate(row,col-c)
    def move_right(self,c=1):
        row=self.cursorY
        col=self.cursorX
        self.locate(row,col+c)
    def move_up(self,c=1):
        row=self.cursorY
        col=self.cursorX
        self.locate(row-c,col)
    def move_down(self,c=1):
        row=self.cursorY
        col=self.cursorX
        self.locate(row+c,col)
    def cursor_on(self):
        self.locate(-1,-1,1)    
    def cursor_off(self):
        self.locate(-1,-1,0)          
    def reverse(self):
        tmp=self.color()
        self.color(tmp[1],tmp[0])
    def getmouse(self):
        self._fbl.fbGetMouse.argtypes = [POINTER(c_int),POINTER(c_int),POINTER(c_int),POINTER(c_int),POINTER(c_int)]
        self._fbl.fbGetMouse.restype =c_int
        return self._fbl.fbGetMouse(byref(self._X),byref(self._Y),byref(self._Wheel),byref(self._Buttons),byref(self._Clip))
    def setmouse(self,x=-1,y=-1,visibility=1,clip=1):
        self._fbl.fbSetMouse.argtypes = [c_int,c_int,c_int,c_int]
        self._fbl.fbSetMouse.restype =c_int
        self._X.value,self._Y.value,self._visibility.value,self._Clip.value=x,y,visibility,clip
        return self._fbl.fbSetMouse(self._X.value,self._Y.value,self._visibility.value,self._Clip.value)
    @property
    def mouseX(self):
        return self._X.value
    @property    
    def mouseY(self):
        return self._Y.value
    @property    
    def wheel(self):
        return self._Wheel.value
    @property    
    def btLeft(self):
        return (self._Buttons.value & 1)==1
    @property    
    def btRight(self):
       return (self._Buttons.value & 2)==2      
    @property    
    def btMiddle(self):
        return (self._Buttons.value & 4)==4
    @property    
    def clip(self):
        return self._Clip.value         
    def mouse_over(self,r,c,h,w):
        # ritorna True se il mouse è nelle coordinate desiderate 
        return (self.mouseY in range(r,r+h))and(self.mouseX in range(c,c+w))
    def mouse_click(self,button,r,c,h,w):
        select={1:self.btLeft,2:self.btRight,3:self.btMiddle}
        if select[button]:
            return self.mouse_over(r,c,h,w)
        else:
            return False     

        
    def inkey(self): 
        self._fbl.fbInkey.restype =c_int
        r=self._fbl.fbInkey()
        if r==0:
            return EXTCHAR
        elif r > 255:
            a=r>>8
            return EXTCHAR+chr(a)
        else:
            return chr(r)

    def getkey(self):
        self._fbl.fbGetKey.restype =c_int
        t=self._fbl.fbGetKey()
        return t
    
    def getch(self):
        a=0
        while a==0:a=self.getkey()
        return a
    
    def getchar(self):
        a=chr(255)
        while a==EXTCHAR:a=self.inkey()
        return a
    def multikey(self,code):
        self._fbl.fbMultiKey.restype =c_int
        self._fbl.fbMultiKey.argtypes =[c_int]        
        return self._fbl.fbMultiKey(code)
    def reverse(self):
        c=self.color()
        self.set_color(c[1],c[0])
    def reset_colors(self):
        self.reset()    
    def fill(self,row,col,h,w,char,fg=LGREY,bg=BLACK):
        #tmp=self.color()
        o=ord(char)
        self._fbl.fbFill.argtypes=[c_int,c_int,c_int,c_int,c_uint,c_uint,c_uint]
        self._fbl.fbFill(c_int(row),c_int(col),c_int(h),c_int(w),c_uint(o),c_uint(fg),c_uint(bg))
        #self.set_color(tmp[0],tmp[1])
    def clear_area(self,row,col,h,w,fg=LGREY,bg=BLACK):
        self._fbl.fbClearArea.argtypes=[c_int,c_int,c_int,c_int,c_uint,c_uint]
        self._fbl.fbClearArea(c_int(row),c_int(col),c_int(h),c_int(w),c_uint(fg),c_uint(bg))

    def color_area(self,row,col,h,w,fg=LGREY,bg=BLACK):
        self._fbl.fbColorArea.argtypes=[c_int,c_int,c_int,c_int,c_uint,c_uint]
        self._fbl.fbColorArea(c_int(row),c_int(col),c_int(h),c_int(w),c_uint(fg),c_uint(bg))
        
    def vseparator(self,row,col,h,relief='SINGLE'):
        relief=relief.upper()
        relief=relief.upper()
        up=self.cornici[relief][9]
        down=self.cornici[relief][8]
        middle=self.cornici[relief][2]
        self.print_at(row,col,up)
        for i in range(1,h): self.print_at(row+i,col,middle)
        self.print_at(row+h,col,down)
        
    def hseparator(self,row,col,w,relief='SINGLE'):
        relief=relief.upper()
        left=self.cornici[relief][6]
        right=self.cornici[relief][7]
        middle=self.cornici[relief][3]
        self.print_at(row,col,left)
        tmp=left+middle*(w-1)+right
  
        self.print_at(row,col,tmp)
        
    def cseparator(self,row,col,relief='SINGLE'):
        relief=relief.upper()
        cross=self.cornici[relief][10]
        self.print_at(row,col,cross)
        
    def box(self,row,col,h,w,relief='SINGLE',title=None):
        relief=relief.upper()
        bo=self.cornici[relief]
        up=bo[0]+bo[3]*(w-1)+bo[1]
        down=bo[4]+bo[3]*(w-1)+bo[5]
        self.print_at(row,col,up)
        for i in range(1,h):
            self.print_at(row+i,col,bo[2])
            self.print_at(row+i,col+w,bo[2])
        self.print_at(row+h,col,down)
        if title is not None:
            l=(w-len(title))//2
            self.print_at(row,col+l,title)
    
    def shadow(self,row,col,h,w,fg=None,bg=None,syb=BLOCK3):
        self.set_color(fg,bg)
        col2=col+w+1
        row2=row+h+1
        for i in range(1,h+1):
            self.print_at(row+i,col2,syb)
        for i in range(1,w+2):
            self.print_at(row2,col+i,syb)
    def pcopy(self,source , destination):
        self._fbl.fbPCopy.argtypes=[c_int,c_int]
        self._fbl.fbPCopy(c_int(source),c_int(destination))        
    def ajust(self,s,width,justify): # giustifica una stringa rispetto a width
        if justify=='left': return s.ljust(width,' ')
        if justify=='right': return s.rjust(width,' ')
        if justify=='center': m=(width-len(s))//2;return  ' '*m + s + ' '*m
    def newArea(self,h,w):
        self._fbl.newArea.argtypes=[c_int,c_int]
        self._fbl.newArea.restype=POINTER(Area)        
        return self._fbl.newArea(c_int(h),c_int(w))      
    def put(self,buff,h,w):
        self._fbl.fbPut.argtypes=[POINTER(Area),c_int,c_int]
        self._fbl.fbPut.restype=c_int
        return self._fbl.fbPut(buff,c_int(h),c_int(w))
    def get(self,buff,h,w):
        self._fbl.fbGet.argtypes=[POINTER(Area),c_int,c_int]
        self._fbl.fbGet.restype=c_int
        return self._fbl.fbGet(buff,c_int(h),c_int(w))    
    def deallocateArea(self,pt):
        self._fbl.fbDeallocateArea.argtypes=[POINTER(Area)]
        self._fbl.fbDeallocateArea(pt)        
    def allocate(self, count):
        self._fbl.fbAllocate.argtypes=[c_uint]
        self._fbl.fbAllocate.restype=c_void_p
        return self._fbl.fbAllocate(c_uint(count))
    def deallocate(self,pt):
        self._fbl.fbDeallocate.argtypes=[c_void_p]
        self._fbl.fbDeallocate(pt)           
