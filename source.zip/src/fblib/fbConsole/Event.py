EV_OVER  = 0
EV_IS_OVER= 1
EV_CLICK=  2
EV_IS_CLICK=3
EV_KEYBOARD=4

from fblib.fbConsole.fbConsole import *
from threading import Thread

class Event:
    def __init__(self,term):
        self._term=term
        self._t=Thread(target=self._loop_)
        self._running = True
        self._stack=[]
        self._index=0
    def terminate(self):
        self._running = False
    def mouse_over(self,obj,row,col,h,w,*args,**kargs):
        self._stack.append((EV_OVER,obj,row,col,h,w,args,kargs))
    def is_mouse_over(self,obj,*args,**kargs):
        self._stack.append((EV_IS_OVER,obj,args,kargs))
    def mouse_click(self,obj,but,row,col,h,w,*args,**kargs):
        self._stack.append((EV_CLICK,obj,but,row,col,h,w,args,kargs))
    def is_mouse_click(self,obj,but,*args,**kargs):
        self._stack.append((EV_IS_CLICK,obj,but,args,kargs))
    def keyboard(self,obj,sel,key,*args,**kargs ):
        self._stack.append((EV_KEYBOARD,obj,sel,key,args,kargs))        
    def mainloop(self):
        self._t.start()
    def _loop_(self):    
        while self._running:
            self._term.getmouse()
            op=self._stack[self._index]
            if op[0]== EV_OVER:
               if op[1].mouse_over(op[2],op[3],op[4],op[5]): #se è sopra l'area
                   op[1].repaint(*op[6],**op[7])
            elif  op[0]== EV_IS_OVER:  #se è sopra al widget
               if op[1].is_mouse_over():
                  op[1].action(*op[2],**op[3])
            elif op[0]== EV_CLICK:
               if op[1].mouse_click(op[2],op[3],op[4],op[5],op[6]): #click sopra l'area
                   op[1].repaint(*op[6],**op[7])
            elif  op[0]== EV_IS_CLICK:
                if op[1].is_mouse_click(op[2]):
                    op[1].action(*op[3],**op[4])
            elif  op[0]== EV_KEYBOARD: #hotkey
                if self._term.multikey(op[2]) and self._term.multikey(op[3]):
                    op[1].action(*op[4],**op[5])
            self._index+=1    
            if self._index<0: self._index=len(self._stack)-1
            elif self._index>=len(self._stack): self._index=0
                
