from fblib.fbConsole.Widgets import *
class Entry(Widgets):
    def __init__(self,parent,row,col,**kargs):
        super().__init__(parent,row,col,**kargs)
        self._con=Write(parent)
        self._index=0
        if not 'multi_edit' in self._var: self._var['multi_edit']=False        
        if self._var['relief'] is not None:self._var['row']+=1
        if self._var['relief'] is not None:self._var['col']+=1
        self._con.set_color(self._var['fg'],self._var['bg'])
        self._con.print_at(self._var['row'],self._var['col'],' '*self._var['width'])
        l=len(self._var['text'])
        self.paint()
        if l>0:self._con.print_at(self._var['row'],self._var['col'],self._var['text']);self._index=l-1 
    def paint(self):
        if self._var["relief"] is not None:
            row=self._row_-1
            col=self._col_-1
            fg,bg=self._color_()
            self._term.clear_area(row,col,self._var['height'],self._var['width']+1,fg=fg,bg=bg)
            self._term.box(row,col,self._var['height'],self._var['width']+1,relief=self._var['relief'])    
    def _delFirstchar(self):   #cancella il primo carattere
        self._var['text']=self._var['text'][1:]
    def _delLastchar(self):   #cancella l'ultimo carattere
        self._var['text']=self._var['text'][:-1]
    def _delMiddlechar(self):   #cancella il carattere nella posizione index -1
        l=self._var['text'][:self._index-1]
        r=self._var['text'][self._index:]
        self._var['text']=l+r
    def _delActualPos(self):   #cancella il carattere nella posizione attuale
        l=self._var['text'][:self._index]
        r=self._var['text'][self._index+1:]
        self._var['text']=l+r        
    def _insertFirstchar(self,s): #inserisci un carattere nella prima posizione
        if  len(self._var['text'])< self._var['width']:
            if self._command is not None:   #funzione di controllo
                s=self._command(s)
            self._var['text']=s+self._var['text']
    def _insertLastchar(self,s):  #inserisci un carattere nell'ultima posizione
        if  len(self._var['text'])< self._var['width']:
            if self._command is not None:    #funzione di controllo
                s=self._command(s)            
        self._var['text']+=s
    def _insertMiddlechar(self,s): #inserisci un carattere in posizione centrale
        if  len(self._var['text'])< self._var['width']:
            if self._command is not None: #funzione di controllo
                s=self._command(s)
        l=self._var['text'][:self._index]
        r=self._var['text'][self._index:]            
        self._var['text']=l+s+r        
    def input(self):     #esegue l'input
        fg,bg=self._color_()
        self._con.set_color(fg,bg)
        self._con.print_at(self._var['row'],self._var['col'],' '*self._var['width'])
        self._con.print_at(self._var['row'],self._var['col'],self._var['text'])                
        mode=I_INS
        char=ascii_lowercase+ascii_uppercase+digits
        while True:
            i= self._index if self._index <= self._var['width'] else self._var['width'] 
            self._con.locate(self._var['row'],self._var['col']+i)
            s=self._term.getchar() # attende la pressione di un tasto
            if not self.isDisable():
                if (s in  char or s in punctuation ):
                    if mode==I_INS:
                        if self._index==0 and len(self._var['text'])<=self._var['width']: #in testa
                            self._insertFirstchar(s)
                            self._index+=1
                        elif self._index==len(self._var['text'])and len(self._var['text'])<self._var['width']:#in coda
                             self._insertLastchar(s)
                             self._index+=1        
                        elif self._index<len(self._var['text']) and len(self._var['text'])<self._var['width']: # al centro
                             self._insertMiddlechar(s)
                             self._index+=1                                            
                    elif  mode=='NoIns':
                        if self._index==0:
                            self._delFirstchar()
                            self._insertFirstchar(s)
                        elif self._index==len(self._var['text']):
                            self._delLastchar()
                            self._insertLastchar(s)
                        else:
                            self._delMiddlechar()
                            self._insertMiddlechar(s)
                elif s==I_INS:   ### INS
                    mode=I_INS if mode!= I_INS else 'NoIns'
                elif s==I_BACKSPACE:  ### BACKSPACE
                    if self._index==0:
                        self._delFirstchar()
                        self._index=1 
                    elif self._index==len(self._var['text']):
                        self._delLastchar()
                        self._index-=1 
                    else:                     
                        self. _delActualPos()
                    self._index-=1    
                elif s==I_CANC: ### CANC
                    if self._index==0:
                        self._delFirstchar()
                    elif self._index==len(self._var['text']):
                        self._delLastchar()
                    elif self._index <len(self._var['text']):                     
                        self._delActualPos()
                elif s==I_LEFT:  ### LEFT
                    if self._index in range(1,self._var['width']+1): self._index-=1
                elif s==I_RIGHT : ### RIGHT
                    if self._index in range(self._var['width']+1): self._index+=1 
                elif s==I_HOME:  ### HOME
                    self._index=0
                elif s==I_END:  ### END
                    self._index=len(self._var['text'])-1
            if s==I_ENTER:  ### ENTER esci input terminato
                    return I_ENTER      
            elif s==I_TAB:  # TAB esci widget successivo
                if self._var['multi_edit']: return I_TAB
            elif s==I_UP:  # Up esci input precedente
                if self._var['multi_edit']: return I_UP
            elif s==I_DOWN:  # Down esci input successivo
                if self._var['multi_edit']: return I_UP
            elif s==I_ESCAPE:  # I_ESCAPE esci
                if self._var['multi_edit']: return I_ESCAPE                    
            self._con.print_at(self._var['row'],self._var['col'],' '*self._var['width'])
            self._con.print_at(self._var['row'],self._var['col'],self._var['text'][:self._var['width']])

