from fblib.fbConsole import *
from fblib.fbConsole.Window import *
from fblib.fbTypes import *
from fblib.Costant import *

class Draw:
    def __init__(self, win):
        self._win=win
        self._term=win.term
    def box(self,row,col,h,w,relief='SINGLE',title=None):
        if self._win.valid_area(row,col,h,w): # se rientra nella finestra
            self._term.box(self._win['row']+row,self._win['col']+col,h,w,relief=relief,title=title)
    def vseparator(self,row,col,h,relief='SINGLE'):
        if (row+h) in range(1,self._win['height']):
            self._term.vseparator(self._win['row']+row,self._win['col']+col,h,relief=relief)
    def hseparator(self,row,col,w,relief='SINGLE'):
        if (col+w) in range(1,self._win['width']):
            self._term.hseparator(self._win['row']+row,self._win['col']+col,w,relief=relief)
    def cseparator(self,row,col,relief='SINGLE'):
        r1= row in range(1,self._win['height']);c1 =col in range(1,self._win['width'])
        if r1 and c1:
            self._term.cseparator(self._win['row']+row,self._win['col']+col,relief=relief)                     
        
    def rbox(self,row,col,nrow,width,fg=WHITE,bg=DGREY,relief='SINGLE',title=''):
        r=nrow*2 ; h=r+2 
        self._term.set_color(fg,bg)
        self.box(row,col,h,width,relief=relief,title=title)
        for i in range(2,h,2):
            self.hseparator(row+i,col,width,relief=relief)
