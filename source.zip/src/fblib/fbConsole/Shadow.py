from fblib.fbConsole.fbConsole import *
from fblib.fbConsole.Window import *
from fblib.fbTypes import *

class Shadow:
    def __init__(self,win):
        self._win=win
        self._term=win.term
    def shadow(self,row,col,h,w,fg=None,bg=None,syb=BLOCK3): # ombra all'interno della finestra
        fg=fg if fg is not None else self._win['fg']
        bg=bg if bg is not None else self._win['bg']
        c=self._term.color() # salva i colori attuali
        if self._win.valid_area(row,col,h,w): # se rientra nella finestra
            self._term.shadow(self._win['row']+row,self._win['col']+col,h,w,fg=fg,bg=bg,syb=syb)
        self._term.set_color(c[0],c[1]) # ripristina i colori    
    def wshadow(self,fg=LGREY,bg=BLACK,syb=BLOCK3): # ombra della finestra
        c=self._term.color() # salva i colori attuali
        self._term.shadow(self._win['row'],self._win['col'],self._win['height'],self._win['width'],fg=fg,bg=bg,syb=syb)
        self._term.set_color(c[0],c[1]) # ripristina i colori    
