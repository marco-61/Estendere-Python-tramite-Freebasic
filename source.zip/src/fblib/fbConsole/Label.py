from fblib.fbConsole.Widgets import *

class Label(Widgets):
    def __init__(self,parent,row,col,**kargs):
        super().__init__(parent,row,col,**kargs)
        self._con=Write(self._parent)
        self._border=False; self._buff=None
        self.paint()
    def paint(self):
        if self.isVisible():
            fg,bg=self._color_()     
            self._con.set_color(fg,bg)
            txt=self._var['text']
            self._con.print_at(self._var['row'],self._var['col'],txt[:self._var['width']])
       
    def border(self):
        if not self._border:
            self._buff=self._term.newArea(self._var['height'],self._var['width']+1)
            self._term.get(self._buff,self._row_-1,self._col_-1) # salva l'area
            self._border=True
        self._var['relief']='DOUBLE' if self._var['relief']=='SINGLE' else 'SINGLE'
        self._term.box(self._row_-1,self._col_-1,self._var['height'],self._var['width']+1,relief=self._var['relief'])    
        self.paint()
               
    def clear_border(self):
        if self._border:
            self._term.put(self._buff,self._row_-1,self._col_-1)#ripristina l'area
            self._term.deallocateArea(self._buff)
            self._border=False
            self.paint()

