from fblib.fbConsole.fbConsole import *
from fblib.fbConsole.Window import *
from fblib.fbTypes import *
from fblib.Costant import *

class Write:
    def __init__(self, win):
        self._win=win
        self._term=win.term
        self._cstack=[] #color stack        
    def print(self,text):
        self.locate(self._win['cursorY']-self._win['row'],self._win['cursorX']-self._win['col'])  
        self._term.print(text)
    def cprint(self,fg,bg,text):
        r=self._win.wcalc(self._win['cursorY'],self._win['cursorX']) 
        self._term.locate(r[0],r[1])
        self._term.cprint(fg,bg,text[:r[2]])
        self._win['active_fg']=fg;self._win['active_bg']=bg
        self._win['cursorX']+=len(text[:r[2]]) # aggiorna per la lunghezza del testo scritto
    def print_at(self,row,col,text):
        self.set_color() # scrivi con i colori della finestra
        if '\n' in text:
            t=text.split('\n')
            i=0
            for l in t:
                r=self._win.wcalc(row+i,col)
                self._term.print_at(r[0],r[1],t[i][:r[2]])
                i+=1
            self._win['cursorX']+=len(t[i-1][:r[2]]) # aggiorna per la lunghezza del testo scritto       
        else:
            r=self._win.wcalc(row,col)
            self._term.print_at(r[0],r[1],text[:r[2]])
            self._win['cursorX']+=len(text[:2]) # aggiorna per la lunghezza del testo scritto        
    def set_color(self, fg=None, bg=None):
        fg=fg if fg is not None else self._win['active_fg']
        bg=bg if bg is not None else self._win['active_bg']                       
        self._term.set_color(fg,bg)
        self._win['active_fg']=fg;self._win['active_bg']=bg
    def color(self):
        return (self._win['active_fg'],self._win['active_bg'])
    def screen(self,row,col,colorflag=0):
        return self._term.screen(self._win['row']+row,self._win['col']+col,colorflag)
    def locate(self,row,col):
        r=self._win.wcalc(row,col)
        self._term.locate(r[0],r[1])
    def reverse(self):
        tmp=self.color()
        self.set_color(tmp[1],tmp[0])    
    def reset(self):
        self.set_color(self._win['fg'],self._win['bg'])
        self._win['active_fg']=self._win['fg'];self._win['active_bg']=self._win['bg']
    def clear_area(self,row,col,h,w,fg=None,bg=None):
            self.fill(row,col,h,w,' ',fg,bg)
    def cls(self):
        self.clear_area(1,1,self._win['height'],self._win['width'],fg=self._win['fg'],bg=self._win['bg'])
    def fill(self,row,col,h,w,char,fg=None,bg=None):
        fg=fg if fg is not None else self._win['fg']
        bg=bg if bg is not None else self._win['bg']
        if self._win.valid_area(row,col,h,w): # se rientra nella finestra                       
            self._term.fill(self._win['row']+row,self._win['col']+col,h,w,char,fg=fg,bg=bg)        
   def color_area(self,row,col,h,w,fg=None,bg=None):
        fg=fg if fg is not None else self._win['fg']
        bg=bg if bg is not None else self._win['bg']
        if self._win.valid_area(row,col,h,w): # se rientra nella finestra                       
            self._term.color_area(self._win['row']+row,self._win['col']+col,h,w,fg=fg,bg=bg)     
    def cpush(self): #salva i colori attuali
        self._cstack.append((self._win['active_fg'],self._win['active_bg']))
                                                                  
    def cpop(self):
        if len(self._cstack)>0:
            c=self._cstack.pop()
            fg,bg=c                                                                                                           
        else:
            fg,bg=LGREY,BLACK # stack vuoto colori di default
        self.set_color(self._win['fg'],self._win['bg'])# riprista i colori
        self._win['active_fg']=fg; self._win['active_bg']=bg
                                                                  
