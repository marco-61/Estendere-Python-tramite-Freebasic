from fblib.fbConsole.fbConsole import *
from fblib.fbConsole.Window import *
from fblib.fbConsole.Entry import *
term=fbConsole()
win=Window(term,5,5,10,30,fg=RED,bg=LGREY)
e1=Entry(win,3,5,text='default',fg=RED,bg=YELLOW,multi_edit=True)
e1.input()
term.sleep()
