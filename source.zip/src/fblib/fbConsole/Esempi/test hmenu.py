from fblib.fbConsole.Screen import Screen
from fblib.fbConsole.Write import *
from fblib.Costant import *
from fblib.fbConsole.Widgets import *
from fblib.fbConsole.Label import *
from fblib.fbConsole.Hmenu import *

def test1(but):
    term.print_at(15,10,f'Selezionato la Voce n.{but+1}')  
    
term=fbConsole()
scr=Screen(term,fg=WHITE,bg=LBLUE)
m=Hmenu(scr,10,10,fg=RED,bg=YELLOW,escape=True)
m.choise('Voce 1',test1)
m.choise('Voce 2',test1)
m.choise('Voce 3',test1)
m.choise('Voce 4',test1)
m.choise('Voce 5',test1)
m.choise('Voce 6',test1)
m.select()                  
