from fblib.fbConsole.fbConsole import *
from string import ascii_lowercase,ascii_uppercase,digits,punctuation
con=fbConsole()

def winput(con,row,col,width,fg,bg,command=None):
    buffer=''
    index=0
 
    con.set_color(fg,bg)
    con.print_at(row,col,' '*width)
    mode=I_INS
    char=ascii_lowercase+ascii_uppercase+digits
    while True:
        i= index if index < width else width-1
        con.locate(row,col+i)
        s=con.getchar()
        if (s in  char or s in punctuation ):
            if mode==I_INS and index<len(buffer)-1: ### 
                l=buffer[:index]
                r=buffer[index:]
                if command is not None: #funzione di controllo
                    s=command(s)
                    buffer=l+s+r
                    index+=1
                else:       
                    buffer=l+s+r
                    index+=1
            elif mode==I_INS and index==len(buffer)-1: #in coda   
                if command is not None: #funzione di controllo
                    s=command(s)
                    buffer+=s
                    index+=1
                else:       
                    buffer+=s
            else: #soprappone
                l=buffer[:index]
                r=buffer[index+1:]
                if command is not None: #funzione di controllo
                    s=command(s)
                    buffer=l+s+r
                    index+=1
                else:
                    buffer=l+s+r
                    index+=1
        elif s==I_INS:   ### INS
            mode=I_INS if mode!= I_INS else 'NoIns'
        elif s==I_BACKSPACE:  ### BACKSPACE
            if index>0:
                l=buffer[:index-1]
                r=buffer[index:]
                buffer=l+r
                index-=1
        elif s==I_CANC: ### CANC
            if index==len(buffer)-1:
                buffer=buffer[:-1]
            elif index==0:
                buffer=buffer[1:]
                
            else:    
                l=buffer[:index-1]
                r=buffer[index+1:]
                buffer=l+r
                
        elif s==I_LEFT:
            if index>0: index-=1
        elif s==I_RIGHT :
            if index<len(buffer)-1: index+=1
        elif s==I_HOME:  ### HOME
            index=0
        elif s==I_END:  ### END
            index=len(buffer)-1
        elif s==I_ENTER:  ### ENTER
            return buffer
        if index >= width:
            start=len(buffer)-width
            con.print_at(row,col,' '*width)
            con.print_at(row,col,buffer[start:])
        else:
            con.print_at(row,col,' '*width)
            con.print_at(row,col,buffer[:width])
        
if __name__=='__main__':
    def upper(s):
        return s.upper()
    con.print_at(23,4,'Hai Scelto {}'.format(winput(con,5,5,10,RED,YELLOW,command=upper)))
    con.sleep() 
