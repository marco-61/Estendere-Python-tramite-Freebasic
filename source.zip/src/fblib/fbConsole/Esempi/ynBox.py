from fbConsole.fbConsole import *
from fbConsole.Window import *
from fbConsole.Widgets import *
from fbConsole.Label import *
from fbConsole.Button import *
from fbConsole.Costant import *
from fbConsole.Write import *



def ynBox(term,msg,fg=BLACK,bg=WHITE):
    term=term
    H=term.lines();W=term.columns()   
    win=Window(term,H//4,W//4,10,30,fg=fg,bg=bg,repaint=None,title='Select')
    l1=Label(win,2,10,text=msg,width=30,fg=fg,bg=bg)
    b1=Button(win,7,4,text='Si',fg=fg,bg=bg)
    b1.border()# bordo doppio opzione di default
    b2=Button(win,7,18,text='No',fg=fg,bg=bg)
    con=Write(win)
    con.set_color(fg,bg)
    #con.print_at(2,2,msg)
    x=1
    while True:
        s=term.inkey()# termtrollo keyboard
        m=term.getmouse()
        if s==chr(13):
            term.cursor_on()
            break
        elif s==I_LEFT:
            if x==1:
                x+=1
                b1.border()
                b2.border()
            elif x==2:
                x-=1
                b1.border()
                b2.border()                
        elif s==I_RIGHT:
            if x==1:
                x+=1
                b1.border()
                b2.border()   
            elif x==2:
                x-=1
                b1.border()
                b2.border()   
        elif l1.is_mouse_over():
            l1.reverse() 
        else: #controllo mouse
            
            if m==0:
                if b1.is_mouse_click(1):
                    if x==2:
                        b1.border()
                        b2.border()
                        b1.reverse()
                    b1.action()
                    x=1
                    break
                elif b2.is_mouse_click(1):
                    if x==1:
                        b2.border()
                        b1.border()
                        b2.reverse()
                    b2.action()
                    x=2
                    break
    term.sleep(50)            
    kill(win)        
    return x==1  # True se si False se no

if __name__=='__main__':
   term=fbConsole()   
   if ynBox(term,'Vuoi uscire!',fg=RED,bg=GREEN):
       print('hai scelto si')
   else:
       print('hai scelto no')
   term.sleep()
   
