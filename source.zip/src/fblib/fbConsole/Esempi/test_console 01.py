from fblib.fbConsole.fbConsole import *
from fblib.Costant import *

term=fbConsole()
term.width(120,50) # setta una console 50 righe x 120 colonne
term.set_color(WHITE,LBLUE) # setta bianco su blu brillante
term.cls()  #cancella lo schermo con i nuovi colori
term.locate(5,15) #posiziona il cursore
term.cprint(YELLOW,DGREY,'Testo di prova') #scrive un testo con i nuovi colori
term.reverse() # inverti i colori
term.move_down(5) # sposta il cursore di 5 righe
term.print('Premi un tasto per continuare')
term.sleep()
p1=term.newArea(10,20) # crea un buffer 10 righe x 20 colonne
term.get(p1,5,15) # salva l'area
term.clear_area(5,15,10,20,fg=RED,bg=YELLOW) #cancella l'area
term.print_at(7,20,'Ciao Mondo')
term.sleep(500)
term.box(5,15,10,20,relief='DOUBLE',title='box di prova')
term.sleep(500)
p2=term.newArea(10,20) # crea un buffer 10 righe x 20 colonne
term.get(p2,5,15) # salva l'area
term.put(p1,5,15)#ripristina la vecchia area
term.put(p2,15,15)#riscrive l'area in una altra posizione
term.shadow(15,15,10,20) #crea l'ombra della finestra con i colori e il caratteredi default
term.deallocateArea(p1) # cancella i buffer's
term.deallocateArea(p2)
term.sleep()
