from fblib.fbConsole import *
from fblib.fbConsole.Screen import *
from fblib.fbConsole.Window import *
from fblib.Costant import *
from fblib.fbConsole.Label import *
from fblib.fbConsole.Button import *
from fblib.fbConsole.Entry import *
from fblib.fbConsole.MEdit import *
from fblib.fbConsole.Event import *

def change_color(fg,bg):
    l1['fg']=fg
    l1['bg']=bg
    l1.paint()
    
def reverse():
    l2.reverse()
    
def reverse2():
    l1.reverse()
    
def bt(but):
    term.print_at(22,10,f'Pulsante {but}')

def esci():
    ev.terminate()
    
    
term=fbConsole()
ev=Event(term)
le=MEdit()
scr=Screen(term,fg=WHITE,bg=LBLUE,repaint=reverse2)
l1=Label(scr,5,5,text='Hello Word',fg=RED,bg=GREEN,command=change_color,visible=True)
l2=Label(scr,5,35,text='Ciao ciao',fg=RED,bg=GREEN,command=reverse,visible=True)
b1=Button(scr,10,5,width=15,text='Pulsante 1',fg=BLACK,bg=GREEN,command=bt)
b2=Button(scr,10,30,width=15,text='Pulsante 2',fg=BLACK,bg=GREEN,command=bt)
b3=Button(scr,10,50,width=15,text='Esci',fg=BLACK,bg=GREEN,command=esci)
e1=Entry(scr,14,5,text='Pippo',fg=RED,bg=YELLOW)

le.add(e1)
e2=Entry(scr,16,5,text='De Pippis',fg=RED,bg=YELLOW)
le.add(e2)
ev.keyboard(l1,SC_CONTROL,SC_L ,fg=YELLOW,bg=RED) #scorciatoia cambia colore alla label 1
ev.keyboard(b1,SC_CONTROL,SC_1 ,1) # scorciatoia pulsante 1
ev.keyboard(b1,SC_CONTROL,SC_2 ,2) # scorciatoia pulsante 2
ev.keyboard(b3,SC_CONTROL,SC_E) # scorciatoia pulsante Esci
ev.is_mouse_click(b1,1,1) #click pulsante 1
ev.is_mouse_click(b2,1,2) #click pulsante 1
ev.is_mouse_over(l2) #mouse sopra all'etichetta 2 reverse
ev.is_mouse_click(b3,1) #click pulsante Esci
ev.mouse_over(scr,5,5,2,10) #mouse sopra all'etichetta 2 reverse posizione assoluta
ev.is_mouse_click(le,1) #click su un Entry nel contenitore
ev.mainloop() #event loop

