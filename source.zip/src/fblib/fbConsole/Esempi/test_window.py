from fblib.fbConsole.Window import*
from fblib.fbConsole.Draw import *
from fblib.fbConsole.Write import *
from fblib.Costant import *

def test(relief):   
    draw.box(5,5,15,30,relief=relief)
    draw.hseparator(7,5,30,relief=relief)
    draw.vseparator(5,17,15,relief=relief)    
    draw.cseparator(7,17,relief=relief)
    draw.hseparator(17,5,30,relief=relief)
    draw.cseparator(17,17,relief=relief)      
    con.cpush()
    con.clear_area(6,18 ,1,17,fg=WHITE,bg=LRED)
    con.clear_area(6, 6 ,1,11,fg=YELLOW,bg=LPURPLE)        
    con.clear_area(8, 6 ,9,11,fg=YELLOW,bg=GREEN)
    con.clear_area(8,18 ,9,17,fg=YELLOW,bg=LBLUE)
    con.clear_area(18,6, 2,11,fg=LGREY,bg=WHITE)
    con.clear_area(18,18,2,17,fg=YELLOW,bg=DGREY)    
    con.cpop()
    term.getch()


term=fbConsole()
char=" "*119
term.width(120,50)
term.set_color(2,5)
term.cls()
term.locate(1,1)
for i in range(49): term.cprint(i & 15,5,char)
win=Window(term,2,10,30,40,bg=YELLOW)
con=Write(win)
con.print_at(2,3,"Ciao Mondo")
con.locate(3,3);con.cprint(4,2,'Salve')
term.sleep()
win.border()
con.set_color(RED,YELLOW)
con.print_at(14,2,"ciao Ragazzi, ciao come và")
term.sleep()
win.hide()
term.sleep()
win.show()
win.border()
con.locate(8,2)
#con.reverse();con.print('Hei!')

con.fill(1,1,29,39,'@',fg=WHITE,bg=RED)
con.locate(5,3);
term.sleep()
win.border()
win.move(11,40)
term.sleep()
#con.cls()
win.border()
term.sleep()
draw=Draw(win)# aggiungo funzionalità di disegno cornici interne alla finesta
con.set_color(RED,YELLOW)
c=con.cpush()#salva i colori
test('SINGLE')
term.sleep()
test('DOUBLE')
term.sleep()
con.cpop()#ripristina i colori
kill(win) #elimina la finestra

