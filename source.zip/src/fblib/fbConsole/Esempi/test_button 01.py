from fblib.fbConsole.fbConsole import *
from fblib.fbConsole.Window import *
from fblib.fbConsole.Widgets import *
from fblib.Costant import *
from fblib.fbConsole.Label import *
from fblib.fbConsole.Button import *
term=fbConsole()
term.set_color(BLACK,DGREY)
term.cls()
def bt1():
    term.print_at(22,12,'Pulsante 1 hai scelto Si')
    b1.reverse()
def bt2():
    term.print_at(22,12,'Pulsante 2 hai scelto No')    
    b2.reverse()
#term.cursor_off()    
win=Window(term,10,10,10,30,fg=BLUE,bg=CYAN,repaint=None,title='Mondo')
l1=Label(win,2,10,text='Seleziona',fg=PURPLE,bg=CYAN)
b1=Button(win,7,4,text='Si',fg=RED,bg=WHITE,command=bt1)
b1.border()# bordo doppio opzione di default
b2=Button(win,7,18,text='No',fg=RED,bg=WHITE,command=bt2)

x=1
while True:
    s=term.inkey()# controllo keyboard
    m=term.getmouse()
    if s==chr(13):
        term.cursor_on()
        break
    elif s==I_LEFT or s==I_RIGHT:
        if x==1:
            x+=1
            b1.border()
            b2.border()            
        elif x==2:
            x-=1
            b1.border()
            b2.border()                

    elif l1.is_mouse_over():
        l1.reverse() 
    else: # controllo mouse
        
        if m==0:
            if b1.is_mouse_click(1):
                if x==2:
                    b1.border()
                    b2.border()
                b1.action()
                x=1
                break
            elif b2.is_mouse_click(1):
                if x==1:
                    b2.border()
                    b1.border()
                b2.action()
                x=2
                break            
term.sleep()

