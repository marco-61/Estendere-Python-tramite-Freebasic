from fblib.fbConsole.Window import*
from fblib.fbConsole.Draw import *
from fblib.fbConsole.Write import *
from fblib.Costant import *

def test(relief):   
    draw.box(5,5,15,30,relief=relief)
    draw.hseparator(7,5,30,relief=relief)
    draw.vseparator(5,17,15,relief=relief)    
    draw.cseparator(7,17,relief=relief)
    draw.hseparator(17,5,30,relief=relief)
    draw.cseparator(17,17,relief=relief)      
    con.cpush()
    con.clear_area(6, 6 ,1,11,fg=YELLOW,bg=LPURPLE)
    con.print_at(6,11,'1')    
    con.clear_area(6,18 ,1,17,fg=WHITE,bg=LRED)
    con.print_at(6,25,'2')
    con.clear_area(8, 6 ,9,11,fg=YELLOW,bg=GREEN)
    con.print_at(12,11,'3')
    con.clear_area(8,18 ,9,17,fg=YELLOW,bg=LBLUE)
    con.print_at(12,25,'4')
    con.clear_area(18,6, 2,11,fg=LGREY,bg=WHITE)
    con.print_at(18,11,'5')
    con.clear_area(18,18,2,17,fg=YELLOW,bg=DGREY)
    con.print_at(18,25,'6')
    con.cpop()
    
term=fbConsole()
term.width(120,50)
term.set_color(GREEN,PURPLE)
term.cls()
win=Window(term,2,10,30,40,fg=RED,bg=YELLOW)
con=Write(win)
draw=Draw(win)
con.set_color(RED,YELLOW)
test('SINGLE')
term.sleep(500)
test('DOUBLE')
term.sleep(500)
kill(win) #elimina la finestra
