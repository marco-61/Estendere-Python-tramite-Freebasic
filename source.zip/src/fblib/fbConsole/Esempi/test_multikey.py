from fblib.Costant import *
from fblib.fbConsole.fbConsole import *
term=fbConsole()
term.width(120,50)
term.set_color(RED,LBLUE)
term.cls()
c,r=60,25
print('Premi control-E per uscire')
while not(term.multikey(SC_CONTROL) and term.multikey(SC_E)):
    term.print_at(r,c,'@')
    if term.multikey(SC_LEFT) and c >0:term.print_at(r,c,' ');c-=1
    elif term.multikey(SC_RIGHT) and c <120:term.print_at(r,c,' ');c+=1
    elif term.multikey(SC_UP) and r >0:term.print_at(r,c,' ');r-=1
    elif term.multikey(SC_DOWN) and r <50:term.print_at(r,c,' ');r+=1
    term.sleep(15,1)

