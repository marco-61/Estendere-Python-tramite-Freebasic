from fblib.fbConsole.Screen import Screen
from fblib.Costant import *
from fblib.fbConsole.Hmenu import *
from fblib.fbConsole.Vmenu import *

def test1(but):
    term.print_at(20,10,f'Selezionato la Voce n.{but+1}')  
    
term=fbConsole()
scr=Screen(term,fg=WHITE,bg=LBLUE)
v1=Vmenu(scr,3,2,fg=RED,bg=YELLOW,escape=True)
v1.choise('Nuovo',test1)
v1.choise('Apri',test1)
v1.choise('Salva',test1)
v1.choise('Salva con nome',test1)
v1.choise('Stampa',test1)
v1.choise('Esci',test1)

v2=Vmenu(scr,3,9,fg=RED,bg=YELLOW,escape=True)
v2.choise('Voce 1',test1)
v2.choise('Voce 2',test1)
v2.choise('Voce 3',test1)
v2.choise('Voce 4',test1)
v2.choise('Voce 5',test1)

v3=Vmenu(scr,3,19,fg=RED,bg=YELLOW,escape=True)
v3.choise('Voce 1',test1)
v3.choise('Voce 2',test1)
v3.choise('Voce 3',test1)

v4=Vmenu(scr,3,29,fg=RED,bg=YELLOW,escape=True)
v4.choise('Voce 1',test1)
v4.choise('Voce 2',test1)
v4.choise('Voce 3',test1)
v4.choise('Voce 4',test1)
v4.choise('Voce 5',test1)
v4.choise('Voce 6',test1)

v5=Vmenu(scr,3,38,fg=RED,bg=YELLOW,escape=True)
v5.choise('Voce 1',test1)
v5.choise('Voce 2',test1)
v5.choise('Voce 3',test1)
v5.choise('Voce 4',test1)
v5.choise('Voce 5',test1)
v5.choise('Voce 6',test1)


m=Hmenu(scr,1,2,fg=RED,bg=YELLOW)
m.choise('File',v1.select)
m.choise('Modifica',v2.select)
m.choise('Formato',v3.select)
m.choise('Visualizza',v4.select)
m.choise(' ? ',v5.select)
m.select()                  


