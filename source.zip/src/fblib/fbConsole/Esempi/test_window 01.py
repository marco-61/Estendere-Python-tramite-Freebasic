from fblib.fbConsole.Window import *
from fblib.Costant import *
term=fbConsole()
term.set_color(RED,LBLUE)
term.cls()

def repaint(fg,bg,text):
    win['fg']=fg
    win['bg']=bg
    win.paint()
    win.border()
    term.locate(10,20)
    term.cprint(WHITE,LGREEN,text)

win=Window(term,5,5,15,30,fg=YELLOW,bg=LRED,repaint=repaint)    
term.locate(10,20)
term.cprint(WHITE,LGREEN,'testo 1')
term.sleep(600) # ritardo
win.repaint(GREEN,BROWN,'testo 2')
term.sleep(600)
