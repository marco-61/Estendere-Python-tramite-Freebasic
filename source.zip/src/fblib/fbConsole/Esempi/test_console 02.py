from fblib.fbConsole.fbConsole import *
from fblib.Costant import *

term=fbConsole()
term.width(120,50) # setta una console 50 righe x 120 colonne
term.set_color(PURPLE,DGREY) # setta bianco su blu brillante
term.cls()  #cancella lo schermo con i nuovi colori
term.print_at(22,2,"Clicca su l'area per cambiare colore")
term.print_at(23,2,'oppure premi Escape per uscire')
term.set_color(RED,YELLOW)
term.fill(10,10,10,10,BLOCK3,fg=RED,bg=YELLOW)

Loop=True
while Loop:

    
    s=term.inkey()
    m=term.getmouse()
    if s==I_ESCAPE: #escape per uscire
        Loop=False
    elif term.mouse_click(1,10,10,10,10): #pulsante sinistro premuto
        term.reverse()
        c=term.color()
        term.fill(10,10,10,10,BLOCK3,fg=c[0],bg=c[1]) 
