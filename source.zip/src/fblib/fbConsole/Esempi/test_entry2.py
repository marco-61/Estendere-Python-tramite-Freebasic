from fblib.fbConsole.fbConsole import *
from fblib.fbConsole.Window import *
from fblib.fbConsole.Widgets import *
from fblib.fbConsole.Entry import *
from fblib.fbConsole.MEdit import *
from fblib.fbConsole.Write import *
term=fbConsole()
win=Window(term,5,5,12,30,fg=RED,bg=LGREY)
con=Write(win)
le=MEdit()
con.locate(1,5)
con.cprint(RED,LGREY,'Nome')
e1=Entry(win,2,5,text='Luca',fg=RED,bg=YELLOW)
le.add(e1)
con.locate(5,5)
con.cprint(RED,LGREY,'Cognome')
e2=Entry(win,6,5,text='Mastriani',fg=RED,bg=YELLOW)
le.add(e2)
le.action()
con.print_at(11,2,f"Nome {e1['text']} Cognome {e2['text']}")
term.sleep()
