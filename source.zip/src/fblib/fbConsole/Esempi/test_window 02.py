from fblib.fbConsole.Window import *
from fblib.Costant import *
from fblib.fbConsole.Write import *
term=fbConsole()
term.set_color(RED,LBLUE)
term.cls()

def repaint(fg,bg,text):
    win['fg']=fg
    win['bg']=bg
    win.paint()
    win.border()
    con.locate(5,5)
    con.cprint(fg,bg,text)

win=Window(term,5,5,15,30,fg=YELLOW,bg=LRED,repaint=repaint)
con=Write(win)
#Utilizza le coordinate relative alla finestra
con.locate(5,5)
con.cprint(WHITE,GREEN,'In quel ramo del lago di Como')
term.sleep() # ritardo
win.repaint(GREEN,WHITE,'che volge a mezzogiorno')
term.sleep()
