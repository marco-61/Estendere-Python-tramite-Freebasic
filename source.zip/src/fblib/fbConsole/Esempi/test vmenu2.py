from fblib.fbConsole.Screen import Screen
from fblib.fbConsole.Write import *
from fblib.Costant import *
from fblib.fbConsole.Widgets import *
from fblib.fbConsole.Draw import *
from fblib.fbConsole.Vmenu import *


def test1(but):
    term.print_at(24,10,f'Selezionato la Voce n.{but+1}')  
term=fbConsole()
scr=Screen(term,fg=WHITE,bg=LBLUE)
draw=Draw(scr)
draw.rbox(9,9,5,11,fg=RED,bg=LBLUE,relief='DOUBLE')
m=Vmenu(scr,10,12,fg=RED,bg=YELLOW,escape=True)
m.choise('Voce 1',test1)
m.space()
m.choise('Voce 2',test1)
m.space()
m.choise('Voce 3',test1)
m.space()
m.choise('Voce 4',test1)
m.space()
m.choise('Voce 5',test1)
m.space()
m.choise('Voce 6',test1)
m.select()                  
