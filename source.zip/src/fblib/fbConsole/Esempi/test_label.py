#test Label
from fblib.Costant import *
from fblib.fbConsole.fbConsole import *
from fblib.fbConsole.Draw import *
from fblib.fbConsole.Label import Label
from fblib.fbConsole.Write import *
from fblib.fbConsole.Screen import Screen
from fblib.fbConsole.Shadow import *



term=fbConsole()
scr=Screen(term,fg=RED,bg=DGREY) #Oggetto Screen
win=Window(term,5,20,15,40,fg=BLACK,bg=YELLOW) #Finestra'
con=Write(win) # strumenti Scrittura per la finestra'
con2=Write(scr) # strumenti Scrittura per l’oggetto Screen'
con2.set_color(BLACK,GREEN) #colori attivi
sh=Shadow(win)#'strumento per creare ombreggiature intorno o nella finestra
sh.wshadow(fg=BLACK,bg=DGREY)   #crea un ombra intorno alla finestra
con.locate(5,5);con.cprint(BLACK,GREEN,'Ciao Mondo') # Scrive qualcosa nella finestra
term.cursor_off() # cursore invisibile
l1=Label(win,10,5,text="Clicca qui",fg=BLACK,bg=GREEN) #etichett nella finestra
l2=Label(scr,24,20,text='Premi un tasto per nascodere la label',width=37,fg=BLACK,bg=GREEN) #etichetta  nello schermo
term.sleep() #ritardo
l1.hide() #nasconde l’etichetta nella finestra
l2['text']='Premi un tasto per farla riapparire  ' #cambia il testo nell’etichetta sullo schermo
l2.paint() #ridisegna l’etichetta fuori la finestra
term.sleep()
kill(l2)  #elimina l’etichetta sullo schermo
l1.show() #mostra l’etichetta nella finestra
con.set_color(RED,DGREY) #colori della scritta Bordo
con.print_at(10,17,'Bordo')
con2.print_at(24,20,"Passa il mouse qui sopra");
s=''

while True:
    c=term.getmouse()    #leggi il mouse
    s=term.inkey()           #leggi la tastiera
    if s==I_ENTER: # controllo keyboard    se s==Enter esci
        term.cursor_on()  #cursore visibile
        break
    elif s==I_LEFT:
        win.border()
    elif s==I_RIGHT:
        win.border()
    elif scr.mouse_over(24,20,1,25):
        con2.reverse();con2.print_at(24,20,"Passa il mouse qui sopra")
    else:
        if c==0:
            if  l1.is_mouse_click(1):
                l1.reverse()
            elif win.mouse_click(2,10,17,3,10):
                l1.border()
            elif win.mouse_click(1,10,17,3,10):
                l1.clear_border() 
