from fblib.fbConsole import *
from fblib.fbConsole.Window import *
from fblib.fbConsole.Entry import *
from fblib.fbConsole.Write import *
term=fbConsole()
win=Window(term,5,5,10,30,fg=RED,bg=LGREY)
con=Write(win)
le=[]
con.locate(2,5)
con.cprint(RED,LGREY,'Nome')
le.append(Entry(win,3,5,text='Luca',fg=RED,bg=YELLOW,multi_edit=True,disable=True,relief=None))
con.locate(6,5)
con.cprint(RED,LGREY,'Cognome')
le.append(Entry(win,7,5,text='Mastriani',fg=RED,bg=YELLOW,multi_edit=True,relief=None))
loop,i=True,0
while loop: 
    c=le[i].input()
    if c==I_UP:
        if i==0: i=len(le)-1
        else: i-=1
    elif c==I_DOWN or c==I_TAB:
        if i==len(le)-1:i=0
        else: i+=1
    elif c==I_ESCAPE or c==I_ENTER:
        loop=False
term.print_at(19,8,f"Nome {le[0]['text']} Cognome {le[1]['text']}")
term.sleep()
