from fblib.fbConsole import *
from fblib.fbConsole.Screen import *
from fblib.Costant import *
term=fbConsole()
scr=Screen(term,fg=YELLOW,bg=LBLUE)
scr.border()

term.fill(2,2,10,10,'@',fg=WHITE,bg=GREEN)
term.sleep()
term.color_area(2,2,5,5,fg=LRED,bg=GREEN)
term.sleep()
