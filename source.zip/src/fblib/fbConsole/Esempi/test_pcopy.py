from fblib.fbConsole.fbConsole import *
con=fbConsole()
con.width(120,50)
row=con.lines()
col=con.columns()
i=0

con.cls()
con.locate(1,1)
con.set_color(RED,0)
con.print('A'*(row*col))
con.pcopy(0,1)#salva la pagina
#for x in range(10000000):pass
con.sleep()
con.set_color(YELLOW,0)
con.cls()
con.locate(1,1)
con.print('B'*(col*row))
con.pcopy(0,2)#salva la pagina
con.sleep()
#for x in range(10000000):pass
con.set_color(BLUE,0)
con.cls()
con.locate(1,1)
con.print('C'*(col*row))
con.pcopy(0,3)
con.sleep()
#for x in range(8000000):pass
con.set_color(LPURPLE,0)
con.cls()
con.locate(1,1)
con.print('D'*(col*row))
con.pcopy(0,4)
con.sleep()
#for x in range(8000000):pass
con.cls()
con.pcopy(1,0)
con.sleep()
#for x in range(8000000):pass
con.cls()
con.pcopy(2,0)
con.sleep()
#for x in range(8000000):pass
con.cls()
con.pcopy(3,0)
con.sleep()
#for x in range(8000000):pass
con.cls()
con.pcopy(4,0)
for x in range(8000000):pass
