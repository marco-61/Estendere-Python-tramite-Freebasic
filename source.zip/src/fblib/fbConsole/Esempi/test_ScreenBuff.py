from fblib.fbConsole.fbConsole import *
from fblib.fbConsole.ScreenBuff import *
con=fbConsole()
con.width(120,50)
row=con.lines()-2
col=con.columns()-2
i=0
buff=ScreenBuff(con)
#con.cls()
con.locate(1,1)
con.set_color(RED,0)
con.print('A'*(row*col))
for i in range(4):buff.new()# 4 buffer
buff.get(1)#salva la pagina
con.sleep()
con.set_color(YELLOW,0)
#con.cls()
con.locate(1,1)
con.print('B'*(row*col))
buff.get(2)#salva la pagina
con.sleep()
con.set_color(LBLUE,0)
#con.cls()
con.locate(1,1)
con.print('C'*(row*col))
buff.get(3)#salva la pagina
con.sleep()
con.set_color(LPURPLE,0)
#con.cls()
con.locate(1,1)
con.print('D'*(row*col))
buff.get(4)#salva la pagina
for i in range(800000):pass# con.sleep()
#con.cls()
buff.put(1)
for i in range(800000):pass#con.sleep()
#con.cls()
buff.put(2)
for i in range(800000):pass#con.sleep()
#con.cls()
buff.put(3)
for i in range(800000):pass#con.sleep()
#con.cls()
buff.put(4)
for i in range(800000):pass#con.sleep()
buff.delAll()

