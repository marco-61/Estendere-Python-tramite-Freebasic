from fblib.Costant import *
from fblib.fbConsole.Draw import *
from fblib.fbConsole.Shadow import *
from fblib.fbConsole.Window import *
from fblib.fbConsole.Write import *
term=fbConsole()
term.set_color(WHITE,LBLUE)
term.cls()

win=Window(term,5,10,10,20,fg=RED,bg=GREEN,relief='DOUBLE',title='Finestra 1')
draw=Draw(win)
sh=Shadow(win)
con=Write(win)
con.clear_area(3,3,5,10,fg=YELLOW,bg=RED)
draw.box(3,3,5,10)
sh.shadow(3,3,5,10)
sh.wshadow()
term.sleep()
