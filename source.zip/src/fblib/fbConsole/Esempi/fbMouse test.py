# test fbMouse
from fblib.fbConsole.fbConsole import *

m=fbConsole()
m.clear()
m.setmouse(10,10)
while True:
    err=m.getmouse()
    
    if err==0:
        t=f'err={err} x={m.mouseX} y={m.mouseY}  wheel={m.wheel} btLeft={m.btLeft} btRight={m.btRight} btMiddle={m.btMiddle} Clip={m.clip}'
        m.print_at(10,10,t)
        
