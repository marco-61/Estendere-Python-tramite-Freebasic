from fblib.fbConsole.Widgets import *
class Button(Widgets):
    def __init__(self,parent,row,col,**kargs):       
        super().__init__(parent,row,col,**kargs)
        self._con=Write(self._parent)
        if not 'justify' in self._var:self._var['justify']='center'   
        self.paint()   
    def paint(self):    
        super().paint()
        t=self._parent.ajust(self._var['text'],self._var['width']-3,self._var['justify'])
        fg,bg=self._color_()
        self._con.set_color(fg,bg)
        self._con.print_at(self._var['row'],self._var['col']+1,t)        
