# class Window finestre per console
from fblib.fbConsole.fbConsole import *
from fblib.Costant import *
from fblib.fbConsole.WinBase import *

class Screen(WinBase):
    def __init__(self,term,title='',relief='SINGLE',fg=LGREY,bg=BLACK ,repaint=None):
        super().__init__(term,1,1,term.lines()-1,term.columns()-1,title=title,relief=relief,fg=fg,bg=bg,repaint=repaint)
        term.set_color(self._var['fg'],self._var['bg'])
        term.cls(0) 
    def border(self): # sopra scrive il metodo
        self._term.set_color(self._var['fg'],self._var['bg'])
        tmp= 'DOUBLE'if self._var['relief']== 'SINGLE' else 'SINGLE'
        self._var['relief']=tmp
        self._term.box(self._var['row'],self._var['col'],self._var['height']-1,self._var['width']-1,relief=self._var['relief'],title=self._var['title'])    
    
