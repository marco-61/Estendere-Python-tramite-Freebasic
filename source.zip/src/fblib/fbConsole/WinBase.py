# class Window finestre per console
from fblib.fbConsole.fbConsole import *
from fblib.Costant import *

class WinBase:
    def __init__(self,term,row,col,height,width,title='',relief='SINGLE',fg=LGREY,bg=BLACK ,repaint=None):
        self._term=term
        self._repaint=repaint
        self._var={'row':1,'col':1,'height':25,'width':80,'title':'',\
                   'bg':BLACK,'fg':LGREY,'active_bg':BLACK,'active_fg':LGREY,\
                   'relief':'SINGLE','cursorX':1,'cursorY':1}
        self._var['row']=row; self._var['col']=col
        self._var['height']=height; self._var['width']=width; self._var['title']=title
        self._var['relief']=relief; self._var['bg']=bg; self._var['fg']=fg
    @property
    def term(self):
        return self._term
    def paint(self):
        pass # non implementato
    def  repaint(self,*args,**kargs):
        if self._repaint is not None:self._repaint(*args,**kargs) # chiama la funzione di repaint
                                                                  
    def __getitem__(self,key):
        if key in self._var:
            return self._var[key]
        else:
            return None # chiave non presente
                                                                  
    def __setitem__(self,key,value):
        self._var[key]=value
                                                                  
    def __delitem__(self,key):
        if key in self._var: del(self._var[key]) # cancella la chiave se presente
    def __contains__(self,key):
        return key in self._var
    def wcalc(self,r,c):   
        if r in range(1,self._var['height']):
            row=self._var['row']+r
        else:
            row=self._var['row']+self._var['height']-1 # se fuori sposta all'ultima riga
        if c in range(1,self._var['width']):
            col=self._var['col']+c
        else:
            col=self._var['col']+self._var['width']-1 # se fuori sposta all' ultima colonna
        char=self._var['width']-c# numero di caratteri scrivibili
        self._var['cursorY']=r;self._var['cursorX']=c # salva la nuova posizione del cursore
        return (row,col,char)
    def valid_area(self,row,col,h,w):             
        r1=(row>0 and row+h in range(self._var['height']+1))
        c1= (col>0 and col+w in range(self._var['width']+1))
        if r1 and c1: return True
        return False
    
    def ajust(self,s,width,justify): # giustifica una stringa rispetto a width
        return self._term.ajust(s,width,justify)
    
    def border(self):
        self._term.set_color(self._var['fg'],self._var['bg'])
        tmp= 'DOUBLE'if self._var['relief']== 'SINGLE' else 'SINGLE'
        self._var['relief']=tmp
        self._term.box(self._var['row'],self._var['col'],self._var['height'],self._var['width'],relief=self._var['relief'],title=self._var['title'])    

    def mouse_over(self,r,c,h,w):
        # ritorna True se il mouse è nelle coordinate desiderate altrimenti False
        return (self._term.mouseY in range(r-1,r+h))and(self._term.mouseX in range(c,c+w))
    def mouse_click(self,button,r,c,h,w):
        row=self._var['row']+r-1
        col=self._var['col']+c                                              
        select={1:self._term.btLeft,2:self._term.btRight,3:self._term.btMiddle}
        if select[button]:
            return self._term.mouse_over(row,col,h,w)                                      
        else:
            return False
   
